package com.timetableScheduler.controllers;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.*;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;
import com.timetableScheduler.services.SectionRepositoryService;

@Controller
@RequestMapping(path="/coordinator")
public class CoordinatorSignupController {
	private PasswordEncoder passwordEncoder;
	private SchoolRepositoryUserDetailsService schoolService;
	private SectionRepositoryService sectionService;
	private ClassroomRepositoryService classroomService;
	private CoursesRepositoryService courseService;
	Logger logger = LoggerFactory.getLogger(CoordinatorSignupController.class);
	@Autowired
	public CoordinatorSignupController(SchoolRepositoryUserDetailsService schoolService,SectionRepositoryService sectionService,
			ClassroomRepositoryService classroomService,CoursesRepositoryService courseService,PasswordEncoder passwordEncoder) {
		this.schoolService=schoolService;
		this.passwordEncoder=passwordEncoder;
		this.classroomService=classroomService;
		this.courseService=courseService;
		this.sectionService=sectionService;
	}
	@GetMapping("/signup")
	public String getSignupPage(Model model) {
		School new_school=new School();
		model.addAttribute(ModelAttributes.SCHOOL.toString(),new_school);
		model.addAttribute("edit", false);
		return "/coordinator/signup";
	}
	@PostMapping(value="/signup")
	public String postSchoolInfo(HttpSession session,@ModelAttribute("school") School school,Errors errors,Model model) {
		logger.info(school.toString());
		for(Course acourse:school.getCourses()) {
			for(Section asection:school.getSections()) {
				if(acourse.getBatch().equals(asection.getBatch())) {
					acourse.getTakerSection().add(asection);
					asection.getCoursesTaking().add(acourse);
				}
			}
		}
		school.setPassword(passwordEncoder.encode(school.getPassword()));
		School savedSchool=this.schoolService.save(school);
		school.getListClassrooms().forEach(classroom->classroom.setSchool(savedSchool));
		school.getListCourses().forEach(course->course.setSchool(savedSchool));
		school.getListSections().forEach(section->section.setSchool(savedSchool));
		this.classroomService.save(school.getListClassrooms());
		this.courseService.save(school.getListCourses());
		this.sectionService.save(school.getListSections());
		model.addAttribute(ModelAttributes.SCHOOL.toString(), savedSchool);
		session.setAttribute(ModelAttributes.SCHOOL.toString(), savedSchool);
		for(Classroom classrooms:school.getListClassrooms()) {
			logger.info(classrooms.toString());
		}
		return "/coordinator/home";
	}
	@GetMapping(value="/signup/istaken/{username}",produces="text/plain")
	@ResponseBody
	public String isUsernameTaken(@PathVariable("username") String username) {
		if(this.schoolService.loadUserByUsername(username)==null) {
			return "false";
		}
		return "true";
	}
}
