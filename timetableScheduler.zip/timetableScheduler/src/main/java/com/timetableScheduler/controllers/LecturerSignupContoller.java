package com.timetableScheduler.controllers;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.School;
import com.timetableScheduler.repositories.LecturerRepository;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;
@Controller
@RequestMapping(path="/lecturer")
public class LecturerSignupContoller {
	private LecturerRepositoryUserDetailsService lecturerService;
	private SchoolRepositoryUserDetailsService schoolService;
	private CoursesRepositoryService courseService;
	private PasswordEncoder passwordEncoder;
	Logger logger = LoggerFactory.getLogger(LecturerSignupContoller.class);
	@Autowired
	public LecturerSignupContoller(LecturerRepositoryUserDetailsService lecturerService,PasswordEncoder passwordEncoder,
			SchoolRepositoryUserDetailsService schoolService,CoursesRepositoryService courseService) {
		this.passwordEncoder=passwordEncoder;
		this.lecturerService=lecturerService;
		this.schoolService=schoolService;
		this.courseService=courseService;
	}
	@GetMapping("/signup")
	 public String signup(Model model) {
		List<School> schools=new ArrayList<School>();
		List<Course> courses=new ArrayList<Course>();
		this.schoolService.getAllSchools().iterator().forEachRemaining(school->schools.add(school));
		this.courseService.findAll().iterator().forEachRemaining(course->courses.add(course));
		model.addAttribute("schools", schools);
		//model.addAttribute("courses", courses);
		model.addAttribute(ModelAttributes.LECTURER.toString(), new Lecturer());
		return "/lecturer/signup";
	 }
	@PostMapping("/signup")
	public String register(Model model,@ModelAttribute("lecturer") Lecturer lecturer,
			@RequestParam("couldTeacheCourse") String[] couldTeacheCourse,
			Errors errors,@RequestParam("school_id") String school_id) {
		int year_offset=Calendar.getInstance().get(Calendar.YEAR)-2000;
		long current_lecturer=this.lecturerService.count()+1;
		Set<Course> couldteacheCourses=new HashSet<>();
		for(String ids:couldTeacheCourse) {
			couldteacheCourses.add(this.courseService.findById(Integer.parseInt(ids)));
		}
		lecturer.setLecturerId("LEC/"+String.format("%04d",current_lecturer)+"/"+year_offset);
		lecturer.setSchool(this.schoolService.findById(Integer.parseInt(school_id)));
		lecturer.setPassword(this.passwordEncoder.encode(lecturer.getPassword()));
		lecturer.setCouldTeache(couldteacheCourses);
		logger.info(lecturer.toString());
		this.lecturerService.save(lecturer);
		return "/lecturer/login";
	}
	@GetMapping(value="/signup/istaken/{username}",produces="text/plain")
	@ResponseBody
	public String isUsernameTaken(@PathVariable("username") String username) {
		if(this.lecturerService.findByUsername(username)==null) {
			return "false";
		}
		return "true";
	}
	@GetMapping("/signup/getcourses/{schoodId}")
	@ResponseBody
	public ArrayList<String[]> getCourses(@PathVariable("schoodId") String schoodId){
		School school=this.schoolService.findById(Integer.parseInt(schoodId));
		ArrayList<String[]> dataIds=new ArrayList<>();
		this.courseService.findBySchool(school).forEach(courses->{
			String[] internal=new String[2];
			internal[0]=""+courses.getCourseNo();
			internal[1]=courses.getCourseName();
			dataIds.add(internal);
		});
		return dataIds;
	}
}
