package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.el.stream.Stream;
import org.hibernate.Hibernate;
import org.hibernate.SessionFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.validation.Errors;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;
import com.timetableScheduler.services.SectionRepositoryService;

@Controller
@RequestMapping("/coordinator")
public class CoordinatorEditProfileController {
	private  SchoolRepositoryUserDetailsService schoolService;
	private ClassroomRepositoryService classroomService;
	private SectionRepositoryService sectionService;
	private CoursesRepositoryService courseService;
	Logger logger = LoggerFactory.getLogger(CoordinatorEditProfileController.class);
	
	@Autowired
	public CoordinatorEditProfileController(SchoolRepositoryUserDetailsService schoolService,
			ClassroomRepositoryService classroomService,SectionRepositoryService sectionService,
			CoursesRepositoryService courseService) {
		this.schoolService=schoolService;
		this.courseService=courseService;
		this.classroomService=classroomService;
		this.sectionService=sectionService;
	}
	
	@GetMapping("/editprofile")
	public String editProfile(HttpSession session,Model model) {
		School inSessionSchool=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		if(inSessionSchool==null) {
			model.addAttribute("authentication", "Please login again");
			return "/coordinator/login";
		}
		inSessionSchool.setListCourses(this.courseService.findBySchool(inSessionSchool));
		inSessionSchool.setListClassrooms(this.classroomService.findByShool(inSessionSchool));
		inSessionSchool.setListSections(this.sectionService.findBySchoolAll(inSessionSchool));
		model.addAttribute(ModelAttributes.SCHOOL.toString(),inSessionSchool);
		model.addAttribute("edit", true);
		return "/coordinator/signup";
	}
	
	@GetMapping("/editpreference")
	public String editClassroomPreferences(Model model,HttpSession session) {
		School insessionSchool=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		if(insessionSchool==null) {
			model.addAttribute("authentication", "Please login again");
			return "/coordinator/login";
		}
		model.addAttribute("sections", this.sectionService.findBySchoolAll(insessionSchool));
		model.addAttribute("classrooms",this.classroomService.findByShool(insessionSchool));
		model.addAttribute("edit", true);
		return "/coordinator/sectionpreference";
	}
	
	@PostMapping("/submiteditted")
	public String submitEditedProfile(HttpSession session,@ModelAttribute("school") School newSchool,Errors errors,Model model) {
		School exsitingSchool=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		if(exsitingSchool==null) {
			model.addAttribute("authentication", "Please login again");
			return "/coordinator/login";
		}
		updateCourses(newSchool,exsitingSchool);
		updateSection(newSchool,exsitingSchool);
		updateClassroom(newSchool,exsitingSchool);
		linkSectionAndCourses(exsitingSchool);
//		exsitingSchool.getClassrooms().forEach(classroom->logger.info("from not saved school classroom "+classroom.getRoomID()));
//		exsitingSchool.getSections().forEach(section->logger.info("from not saved school section "+section.getSectionId()));
//		exsitingSchool.getCourses().forEach(course->logger.info("from not saved school section "+course.getCourseName()));
		School savedSchool=this.schoolService.save(exsitingSchool);
		savedSchool.getClassrooms().forEach(classroom->logger.info("from saved school classroom "+classroom.getRoomID()));
		savedSchool.getSections().forEach(section->logger.info("from saved school section "+section.getSectionId()));
		savedSchool.getCourses().forEach(course->logger.info("from saved school section "+course.getCourseName()));
		session.setAttribute(ModelAttributes.SCHOOL.toString(), savedSchool);
		return "/coordinator/home";
	}
	
	@PostMapping("/setpreferences")
	public String submitPreferences(HttpServletRequest request,Model model) {
		HttpSession session=request.getSession();
		School school=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		if(school==null) {
			model.addAttribute("authentication", "Please login again");
			return "/coordinator/login";
		}
		Set<Classroom> classroomPreference=null;
		boolean updateSchool=false;
		ArrayList<Section> schoolsSections=this.sectionService.findBySchoolAll(school);
		for(Section section:schoolsSections) {
			String[] classroomIds=request.getParameterValues(String.valueOf(section.getSectionNo()));
			if(classroomIds==null) {
//				logger.info("fchganf");
				continue;
			}
			for(String classroomId:classroomIds) {
				classroomPreference=new HashSet<>();
				List<Classroom> classrooms=this.classroomService.findByShool(school).stream().filter(room->
					room.getRoomNo()==Integer.parseInt(classroomId)).collect(Collectors.toList());
				classrooms.get(0).getPreferringSections().add(section);
				classroomPreference.add(classrooms.get(0));
//				logger.warn(classrooms.get(0).toString()+" "+classrooms.size());
				updateSchool=true;
				section.setClassroomPreference(classroomPreference);
				this.classroomService.save(classrooms.get(0));
				this.sectionService.save(section);
//				logger.info(section.toString());
			}
		}
		if(updateSchool) {
			School savedSchool=this.schoolService.save(school);
			session.setAttribute(ModelAttributes.SCHOOL.toString(), savedSchool);
//			logger.warn(savedSchool.toString());
		}
		return "/coordinator/home";
	}
	
	private void linkSectionAndCourses(School exsitingSchool) {
		ArrayList<Course> existingCourses=this.courseService.findBySchool(exsitingSchool);
		ArrayList<Section> existingSections=this.sectionService.findBySchoolAll(exsitingSchool);
		for(Course acourse:existingCourses) {
			for(Section asection:existingSections) {
				try {
					if(acourse.getBatch().equals(asection.getBatch()) 
							&& !acourse.getTakerSection().contains(asection)) {
						acourse.getTakerSection().add(asection);
						this.courseService.save(acourse);
					}if(acourse.getBatch().equals(asection.getBatch()) && !asection.getCoursesTaking().contains(acourse)) {
						asection.getCoursesTaking().add(acourse);
						this.sectionService.save(asection);
					}else {
//						logger.info("an else condition");
					}
				}catch(NullPointerException ex) {
//					logger.warn("empty entity submited ");
				}
			}
		}
	}
	
	private void updateCourses(School newSchool,School exsitingSchool){
		ArrayList<Course> oldCourses=this.courseService.findBySchool(exsitingSchool);
		for(Course updatedCourse:newSchool.getListCourses()) {
			int currentCourseId=updatedCourse.getCourseNo();
			if(currentCourseId==0) {
				updatedCourse.setSchool(exsitingSchool);
				oldCourses.add(updatedCourse);
				continue;
			}
			for(Course existingCourse:oldCourses) {
				if(existingCourse.getCourseNo()==currentCourseId) {
					existingCourse.setCourseName(updatedCourse.getCourseName());
					existingCourse.setCreditHours(updatedCourse.getCreditHours());
					existingCourse.setBatch(updatedCourse.getBatch());
				}
			}
			
		}
		//Hibernate.initialize(exsitingSchool.getCourses());
		this.courseService.save(oldCourses);
		exsitingSchool.setCourses(new HashSet<Course>(oldCourses));
	}
	
	private void updateSection(School newSchool,School exsitingSchool){
		ArrayList<Section> existingSections=this.sectionService.findBySchoolAll(exsitingSchool);
		for(Section updatedSection:newSchool.getListSections()) {
			int currentSectionId=updatedSection.getSectionNo();
			if(currentSectionId==0) {
				updatedSection.setSchool(exsitingSchool);
				existingSections.add(updatedSection);
				logger.info("new section with id"+currentSectionId);
				continue;
			}
			for(Section existingSection:existingSections) {
				if(existingSection.getSectionNo()==currentSectionId) {
					existingSection.setSectionId(updatedSection.getSectionId());
					existingSection.setSectionSize(updatedSection.getSectionSize());
					existingSection.setBatch(updatedSection.getBatch());
				}
			}
		}
		//Hibernate.initialize(exsitingSchool.getSections());
		this.sectionService.save(existingSections);
		exsitingSchool.setSections(new HashSet<Section>(existingSections));
	}
	
	private void updateClassroom(School newSchool,School exsitingSchool) {
		ArrayList<Classroom> existingClassrooms=this.classroomService.findByShool(exsitingSchool);
		for(Classroom updatedClassroom:newSchool.getListClassrooms()) {
			int currentClassroomId=updatedClassroom.getRoomNo();
			if(currentClassroomId==0) {
				updatedClassroom.setSchool(exsitingSchool);
				existingClassrooms.add(updatedClassroom);
				logger.info("updatedClassroom.getRoomID()="+updatedClassroom.getRoomID());
				logger.info("updatedClassroom.getCapacity()="+updatedClassroom.getCapacity());
				continue;
			}
			for(Classroom existingClassroom:existingClassrooms) {
				if(existingClassroom.getRoomNo()==currentClassroomId) {
					existingClassroom.setCapacity(updatedClassroom.getCapacity());
					existingClassroom.setRoomID(updatedClassroom.getRoomID());
					logger.info("existingClassroom.getRoomID()="+existingClassroom.getRoomID());
					logger.info("existingClassroom.getCapacity()="+existingClassroom.getCapacity());
				}
			}
		}
		//Hibernate.initialize(exsitingSchool.getClassrooms());
		this.classroomService.save(existingClassrooms);
		exsitingSchool.setClassrooms(new HashSet<Classroom>(existingClassrooms));
	}
	
}
