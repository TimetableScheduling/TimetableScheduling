package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.PeriodRepositoryService;

@Controller
@RequestMapping(path="/lecturer")
@PreAuthorize("hasRole('ROLE_LECTURER')")
public class LecturerSetScheduleController {
	private PeriodRepositoryService periodService;
	private LecturerRepositoryUserDetailsService lecturerService;
	Logger logger = LoggerFactory.getLogger(LecturerSetScheduleController.class);
	@Autowired
	public LecturerSetScheduleController(PeriodRepositoryService periodService,LecturerRepositoryUserDetailsService lecturerService
			) {
		this.periodService=periodService;
		this.lecturerService=lecturerService;
	}
	@GetMapping("/setschedule")
	public String setSchedule(Model model,HttpSession session) {
		logger.info("controller invoked");
		Lecturer insession=(Lecturer)session.getAttribute(ModelAttributes.LECTURER.toString());
		ArrayList<Period> periods=new ArrayList<>();
		List<Period> currentPreferencePeriods=this.periodService.getPreferenceOf(insession);
		List<Integer> currentPreference=new ArrayList<>();
		currentPreferencePeriods.forEach(period->currentPreference.add(period.getPeriodId()));
		this.periodService.findAll().iterator().forEachRemaining(period->periods.add(period));
		model.addAttribute("periods", periods);
		model.addAttribute("currentPreference", currentPreference);
		return "/lecturer/setschedule";
	}
	@PostMapping("/setschedule")
	public String saveSchedule(HttpSession session,@RequestParam("selectedPeriods") String[] periodIds,Model model) {
		//saves the periods into the Lecturer object in the session
		Set<Period> periodsSelected=new HashSet<Period>();
		for(String periodId:periodIds) {
			periodsSelected.add(this.periodService.findById(Integer.parseInt(periodId)).get());
		}
		Lecturer insession=(Lecturer)session.getAttribute(ModelAttributes.LECTURER.toString());
		if(insession==null) {
			model.addAttribute("authentication", "Please login again");
			return "/lecturer/login";
		}
		insession.setAvailableAt(periodsSelected);
		this.lecturerService.save(insession);
		logger.info(periodsSelected.toString());
		return "/lecturer/home";
	}
}
