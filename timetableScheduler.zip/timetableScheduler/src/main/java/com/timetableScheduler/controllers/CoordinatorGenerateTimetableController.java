package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ForkJoinPool;
import java.util.concurrent.ForkJoinTask;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.request.async.DeferredResult;

import com.timetableScheduler.algorithm.TimetableGA;
import com.timetableScheduler.constants.Batch;
import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.models.Slot;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.PeriodRepositoryService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;
import com.timetableScheduler.services.SectionRepositoryService;
import com.timetableScheduler.services.SlotRepositoryService;
import com.timetableScheduler.utility.SingleClassSessionWrapper;
import com.timetableScheduler.utility.SlotWrapper;

@Controller
@RequestMapping("/coordinator")
public class CoordinatorGenerateTimetableController {
	private SchoolRepositoryUserDetailsService schoolService;
	private SectionRepositoryService sectionService;
	private ClassroomRepositoryService classroomService;
	private PeriodRepositoryService periodService;
	private CoursesRepositoryService courseService;
	private SlotRepositoryService slotRepository;
	private LecturerRepositoryUserDetailsService lecturerService;
	org.slf4j.Logger  logger = LoggerFactory.getLogger(CoordinatorGenerateTimetableController.class);
	@Autowired
	public CoordinatorGenerateTimetableController(SchoolRepositoryUserDetailsService schoolService,SlotRepositoryService slotRepository,
			SectionRepositoryService sectionService,ClassroomRepositoryService classroomService,PeriodRepositoryService periodService,
			CoursesRepositoryService courseService,LecturerRepositoryUserDetailsService lecturerService) {
		this.slotRepository=slotRepository;
		this.schoolService=schoolService;
		this.sectionService=sectionService;
		this.classroomService=classroomService;
		this.periodService=periodService;
		this.courseService=courseService;
		this.lecturerService=lecturerService;
	}
	@GetMapping("/generatetimetable")
	public String generateTimetable(Model model,HttpSession session) {
		Object possibleSchool=session.getAttribute(ModelAttributes.SCHOOL.toString());
		if(possibleSchool!=null) {
			School school=this.schoolService.findById(((School)possibleSchool).getSchoolID());
			ArrayList<Slot> possibleSlots=this.slotRepository.findBySchool(school);
			model.addAttribute("isScheduleGenerated",possibleSlots!=null && !possibleSlots.isEmpty());
		}
		else {
			model.addAttribute("isScheduleGenerated",null);
		}
		return "/coordinator/generatetimetable";
	}
	@GetMapping("/startgenerating")
	public HttpEntity<String> generateForSchool(HttpSession session,Model model) {
		School this_school=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		School school=this.schoolService.findById(this_school.getSchoolID());
		this.startAsyncGenerate(school);
		return new HttpEntity<String>("OK");
	}
	@GetMapping("/startgenerating/checkdata")
	@ResponseBody
	public ArrayList<String> isSchoolsDataComplete(HttpSession session) {
		//there must be lecturer for every course
		//there must be course for every section
		School school=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		Iterable<Section> schoolsSections=this.sectionService.findBySchoolAll(school);
		ArrayList<Course> schoolsCourses=this.courseService.findBySchool(school);
		ArrayList<String> replies=new ArrayList<>();
		for(Section section:schoolsSections) {
			List<Course> sectionsCourses=this.courseService.findCoursesTakenBy(section);
			boolean isVanueAvalalible=this.classroomService.findByShool(school).
					stream().anyMatch(classroom->classroom.getCapacity()>=section.getSectionSize());
			if(sectionsCourses.isEmpty()) {
				String reply="Section "+section.getSectionId()+" of year "+
						Batch.values()[Integer.parseInt(section.getBatch())-1]+" has no course assigned to it";
				replies.add(reply);
				logger.info(reply);
			}
			if(!isVanueAvalalible) {
				String reply="No classroom can accomodate section "+section.getSectionId()+" of year "+
						Batch.values()[Integer.parseInt(section.getBatch())-1];
				replies.add(reply);
				logger.info(reply);
			}
		}
		for(Course course:schoolsCourses) {
			List<Lecturer> coursesLecturers=this.lecturerService.getLecturersThatCouldTeach(course);
			if(coursesLecturers.isEmpty()) {
				String reply="There is no lecturer that could teach "+course.getCourseName();
				replies.add(reply);
				logger.info(reply);
			}
		}
		return replies;
	}
	private void startAsyncGenerate(School this_school) {
//		logger.info("startAsyncGenerate");
		HashMap<Integer,Integer[]> classroomPreference=getClassroomPreference(this_school);
		HashMap<Integer,Integer[]> periodPreference=getPeriodPreference(this_school);
		com.timetableScheduler.algorithm.Room[] rooms=getRoomsOfSchool(this_school);
		com.timetableScheduler.algorithm.Lecturer[] lecturers=getLecturersOfSchool(this_school);
		com.timetableScheduler.algorithm.Course[] courses=getCoursesInSchool(this_school);
		com.timetableScheduler.algorithm.Section[] sections=getSectionsInSchool(this_school);
		ArrayList<Slot> createdSlots=new ArrayList<>();
		ArrayList<Section> createdSections=new ArrayList<>();
		ArrayList<Classroom> createdClassrooms=new ArrayList<>();
		ArrayList<Course> createdCourses=new ArrayList<>();
		ArrayList<Period> createdPeriods=new ArrayList<>();
		ArrayList<Lecturer> createdLecturers=new ArrayList<>();
		ArrayList<SlotWrapper> slotWrappers=TimetableGA.generateForSchool(classroomPreference,periodPreference,
								rooms,lecturers,courses,sections);
		logger.info(slotWrappers.size()+" slotWrappers");
		this.removeAssociatedSlots(this_school);
		for(SlotWrapper slotWrapper:slotWrappers) {
			Section section=this.sectionService.findById(slotWrapper.getSectionId());
			createdSections.add(section);
			Classroom classroom=this.classroomService.findById(slotWrapper.getClassroomId());
			createdClassrooms.add(classroom);
			Period period=this.periodService.findById(slotWrapper.getPeriodId()).get();
			createdPeriods.add(period);
			Course course=this.courseService.findById(slotWrapper.getCourseId());
			createdCourses.add(course);
			Lecturer lecturer=this.lecturerService.findById(slotWrapper.getLecturerId());
			createdLecturers.add(lecturer);
			Slot aslot=createAssociationsAndGetSlot(section, classroom, lecturer, period, course,this_school);
			createdSlots.add(aslot);
		}
		slotRepository.save(createdSlots);
		this.courseService.save(createdCourses);
		this.periodService.save(createdPeriods);
		this.classroomService.save(createdClassrooms);
		this.sectionService.save(createdSections);
		this.lecturerService.save(createdLecturers);
		this.schoolService.save(this_school);
	}
	private Slot createAssociationsAndGetSlot(Section section,Classroom classroom,
			Lecturer lecturer,Period period,Course course,School school) {
		section.getAssignedAt().add(classroom);
		section.getAssignedLecturers().add(lecturer);
		section.getCoursesTaking().add(course);
		section.getHasClassesAt().add(period);
		
		classroom.getAssignedSections().add(section);
		classroom.getBusyAt().add(period);
		classroom.getCoursesGiven().add(course);
		classroom.getWhoTeachHere().add(lecturer);
		
		period.getAssignedClassrooms().add(classroom);
		period.getAssignedCourses().add(course);
		period.getAssignedLecturers().add(lecturer);
		period.getAssignedSections().add(section);
		
		course.getGivenWhere().add(classroom);
		course.getTakerSection().add(section);
		course.getTeachingTeachers().add(lecturer);
		course.getTimeCourseGiven().add(period);
		
		lecturer.getAssignedPeriods().add(period);
		lecturer.getAssignedSections().add(section);
		lecturer.getCoursesTeaching().add(course);
		lecturer.getTeachesAt().add(classroom);
		
		Slot aslot=new Slot(section,classroom,period,course,lecturer,school);
		classroom.getContainingSlots().add(aslot);
		section.getContainingSlots().add(aslot);
		period.getContainingSlots().add(aslot);
		course.getContainingSlots().add(aslot);
		lecturer.getContainingSlot().add(aslot);
		school.getContainingSlots().add(aslot);
		return aslot;
	}
	private HashMap<Integer,Integer[]> getClassroomPreference(School school) {
//		logger.info("getClassroomPreference");
		HashMap<Integer,Integer[]> classroomPreference=new HashMap<>();
		Iterable<Section> sections=this.sectionService.findBySchoolAll(school);
		for(Section section:sections) {
//			logger.info(section.toString());
			List<Classroom> prefereceClassrooms=this.classroomService.getPreferenceOf(section);
//			logger.info(""+prefereceClassrooms.size());
			if(prefereceClassrooms!=null && !prefereceClassrooms.isEmpty()) {
				Integer[] classroomIds=new Integer[prefereceClassrooms.size()];
				int counter=0;
				for(Classroom classroom:prefereceClassrooms) {
					classroomIds[counter++]=classroom.getRoomNo();
				}
				classroomPreference.put(section.getSectionNo(), classroomIds);
			}
		}
		return classroomPreference;
	}
	private HashMap<Integer,Integer[]> getPeriodPreference(School school) {
//		logger.info("getPeriodPreference");
		HashMap<Integer,Integer[]> periodPreference=new HashMap<>();
		Iterable<Lecturer> lecturers=this.lecturerService.findBySchoolAll(school);
		for(Lecturer lecturer:lecturers) {
//			logger.info(lecturer.toString());
			List<Integer> periodIdArray=new ArrayList<Integer>();
			this.periodService.getPreferenceOf(lecturer).forEach(period->periodIdArray.add(period.getPeriodId()));
//			logger.info(""+periodIdArray.size());
			if(!periodIdArray.isEmpty()) {
				Integer[] periodIds=new Integer[24-periodIdArray.size()];
				int counter=0;
				for(int periodId=1;periodId<=24;periodId++) {
					if(!periodIdArray.contains(periodId)) {
						periodIds[counter++]=periodId;
					}
				}
				periodPreference.put(lecturer.getLecturerNo(), periodIds);
			}
		}
		return periodPreference;
	}
	private com.timetableScheduler.algorithm.Room[] getRoomsOfSchool(School school){
//		logger.info("getRoomsOfSchool");
		ArrayList<Classroom> classrooms=new ArrayList<>();
				this.classroomService.findByShool(school).forEach(classroom->classrooms.add(classroom));
		//no need to check for null or empty
		com.timetableScheduler.algorithm.Room[] rooms=new com.timetableScheduler.algorithm.Room[classrooms.size()];
		int counter=0;
		for(Classroom classroom:classrooms) {
			rooms[counter++]=new com.timetableScheduler.algorithm.Room(classroom.getRoomNo(),classroom.getRoomID(),classroom.getCapacity());
		}
		return rooms;
	}
	private com.timetableScheduler.algorithm.Lecturer[] getLecturersOfSchool(School school){
//		logger.info("getLecturersOfSchool");
		ArrayList<Lecturer> lecturers=new ArrayList<>();
		this.lecturerService.findBySchoolAll(school).forEach(lecturer->lecturers.add(lecturer));
		//no need to check for null or empty
		com.timetableScheduler.algorithm.Lecturer[] teachers=new com.timetableScheduler.algorithm.Lecturer[lecturers.size()];
		int counter=0;
		for(Lecturer lecturer:lecturers) {
			teachers[counter++]=new com.timetableScheduler.algorithm.Lecturer(lecturer.getLecturerNo()
					,lecturer.getFullName(),lecturer.getNumberOfPeriodsWillingToTeach());
		}
		return teachers;
	}
	private com.timetableScheduler.algorithm.Course[] getCoursesInSchool(School school){
//		logger.info("getCoursesInSchool");
		ArrayList<Course> coursesAdminstered=new ArrayList<>();
		this.courseService.findBySchool(school).forEach(course->coursesAdminstered.add(course));
		com.timetableScheduler.algorithm.Course[] coursesForAlgorithm=new com.timetableScheduler.algorithm.Course[coursesAdminstered.size()];
		int counter=0;
		for(Course course:coursesAdminstered) {
			List<Lecturer> lecturersAbleToTeachCourse=this.lecturerService.getLecturersThatCouldTeach(course);
			int[] ableTeachersId;
			if(lecturersAbleToTeachCourse==null) {
				ableTeachersId=new int[0];
			}else {
				ableTeachersId=new int[lecturersAbleToTeachCourse.size()];
				int innerCounter=0;
				for(Lecturer ableLecturer:lecturersAbleToTeachCourse) {
					ableTeachersId[innerCounter++]=ableLecturer.getLecturerNo();
				}
			}
			coursesForAlgorithm[counter++]=new com.timetableScheduler.algorithm.Course(course.getCourseNo(),
					course.getCourseCode(),course.getCourseName(),ableTeachersId);
		}
		return coursesForAlgorithm;
	}
	private com.timetableScheduler.algorithm.Section[] getSectionsInSchool(School school){
//		logger.info("getSectionsInSchool");
		ArrayList<Section> sectionEntities=new ArrayList<>();
				this.sectionService.findBySchoolAll(school).forEach(section->sectionEntities.add(section));
		//no need to check for null or empty
		com.timetableScheduler.algorithm.Section[] sectionsForAlgorithm=new com.timetableScheduler.algorithm.Section[sectionEntities.size()];
		int counter=0;
		for(Section section:sectionEntities) {
			List<Course> coursesSectionTakes=this.courseService.findCoursesTakenBy(section);
			int[] courseIdsSectionTakes;
			if(coursesSectionTakes==null || coursesSectionTakes.isEmpty()) {
				courseIdsSectionTakes=new int[0];
			}else {
				courseIdsSectionTakes=new int[coursesSectionTakes.size()];
				int innerCounter=0;
				for(Course someCourseSectionTakes:coursesSectionTakes) {
					courseIdsSectionTakes[innerCounter++]=someCourseSectionTakes.getCourseNo();
				}
			}
			sectionsForAlgorithm[counter++]=new com.timetableScheduler.algorithm.Section(section.getSectionNo(),section.getSectionId(),
					section.getSectionSize(),courseIdsSectionTakes);
		}
		return sectionsForAlgorithm;
	}
	private void removeAssociatedSlots(School this_school) {
		ArrayList<Slot> schoolsSlots=this.slotRepository.findBySchool(this_school);
		for(Slot slot:schoolsSlots) {
			Course course=this.courseService.findById(slot.getCourse().getCourseNo());
			Section section=this.sectionService.findById(slot.getSection().getSectionNo());
			Lecturer lecturer=this.lecturerService.findById(slot.getLecturer().getLecturerNo());
			Classroom classroom=this.classroomService.findById(slot.getClassroom().getRoomNo());
			Period period=this.periodService.findById(slot.getPeriod().getPeriodId()).get();
			course.getContainingSlots().remove(slot);
			section.getContainingSlots().remove(slot);
			lecturer.getContainingSlot().remove(slot);
			classroom.getContainingSlots().remove(slot);
			period.getContainingSlots().remove(slot);
			this.courseService.save(course);
			this.sectionService.save(section);
			this.lecturerService.save(lecturer);
			this.classroomService.save(classroom);
			this.slotRepository.delete(slot);
			logger.info(slot.toString());
		}
		this.schoolService.save(this_school);
	} 
	private ArrayList<SingleClassSessionWrapper> convert(ArrayList<SlotWrapper> slotWrappers){
		ArrayList<SingleClassSessionWrapper> results=new ArrayList<>();
		for(SlotWrapper slotWrapper:slotWrappers) {
			Period period=this.periodService.findById(slotWrapper.getPeriodId()).get();
			results.add(
				new SingleClassSessionWrapper(
					this.sectionService.findById(slotWrapper.getSectionId()).getSectionId(),
					this.classroomService.findById(slotWrapper.getClassroomId()).getRoomID(),
					period.getDay().ordinal(),
					period.getSession().ordinal(),
					this.courseService.findById(slotWrapper.getCourseId()).getCourseName(),
					this.lecturerService.findById(slotWrapper.getLecturerId()).getEthiopianName()
				)
			);
		}
		return results;
	}
	@GetMapping(value="/getprogress",produces=MediaType.TEXT_PLAIN_VALUE)
	@ResponseBody
	public String getProgress() {
//		logger.info(""+TimetableGA.percent);
		return ""+TimetableGA.percent;
	}
}
