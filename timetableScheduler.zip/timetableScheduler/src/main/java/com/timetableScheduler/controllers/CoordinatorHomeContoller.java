package com.timetableScheduler.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.School;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;

@Controller
@RequestMapping(path="/coordinator")
public class CoordinatorHomeContoller {
	private LecturerRepositoryUserDetailsService lecturerService;
	@Autowired
	public CoordinatorHomeContoller(LecturerRepositoryUserDetailsService lecturerService) {
		this.lecturerService=lecturerService;
	}
	@GetMapping("/home")
	public String home() {
		return "coordinator/home";
	}
	@PostMapping("/approvelecturers")
	public String approve(Model model,@RequestParam("activateLecturers") ArrayList<String> approvedLecturersIDs) {
		for(String lecturerId:approvedLecturersIDs){
			Lecturer lecturer=this.lecturerService.findById(Integer.parseInt(lecturerId));
			lecturer.setApproved(true);
			this.lecturerService.save(lecturer);
		}
		return "/coordinator/home";
	}
}
