package com.timetableScheduler.controllers;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.MediaType;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.condition.MediaTypeExpression;
import org.springframework.web.servlet.mvc.method.RequestMappingInfo;
import org.springframework.web.servlet.mvc.method.annotation.RequestMappingHandlerMapping;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.pdf.PdfWriter;
import com.timetableScheduler.constants.Batch;
import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.models.Slot;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.PeriodRepositoryService;
import com.timetableScheduler.services.SectionRepositoryService;
import com.timetableScheduler.services.SlotRepositoryService;
import com.timetableScheduler.utility.IterableSessionWrapper;
import com.timetableScheduler.utility.SingleClassSessionWrapper;

@Controller
@RequestMapping(path="/lecturer")
@PreAuthorize("@authentication.getAuthorities()[0].getAuthority().equals('ROLE_LECTURER')")
public class LecturerViewScheduleController {
	private SlotRepositoryService slotService;
	private Logger logger=LoggerFactory.getLogger(LecturerViewScheduleController.class);
	@Autowired
	public LecturerViewScheduleController(SlotRepositoryService slotService) {
		this.slotService=slotService;
	}
	@GetMapping("/viewschedule")
	 public String viewSchedule(Model model,HttpSession session) {
		model.addAttribute("classSessions",new IterableSessionWrapper(this.filter(session)));
		return "/lecturer/viewschedule";
	 }
	private ArrayList<SingleClassSessionWrapper> filter(HttpSession session){
		ArrayList<SingleClassSessionWrapper> classSessions=new ArrayList<>();
		Lecturer lecturerWithSession=(Lecturer)session.getAttribute(ModelAttributes.LECTURER.toString());
		Iterable<Slot> requiredSlots=this.slotService.findByLecturer(lecturerWithSession);
		for(Slot slot:requiredSlots) {
			logger.info("feG");
			Classroom classroom=slot.getClassroom();
			Section section=slot.getSection();
			Course course=slot.getCourse();
			String detailedSectionInfo=Batch.values()[Integer.parseInt(section.getBatch())-1]+" year "+section.getSectionId();
			String detailedCourseInfo=course.getCourseCode()+"-"+course.getCourseName();
			classSessions.add(new SingleClassSessionWrapper(
					detailedSectionInfo,classroom.getRoomID(),slot.getPeriod().getDay().ordinal(),
					slot.getPeriod().getSession().ordinal(),detailedCourseInfo));
		}
		return classSessions;
	}
}
