package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpRequest;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;

@Controller
@RequestMapping(path="/coordinator")
public class CoordinatorLoginController {
	private PasswordEncoder passwordEncoder;
	private SchoolRepositoryUserDetailsService schoolService;
	private AuthenticationManager authManager;
	private LecturerRepositoryUserDetailsService lecturerService;
	@Autowired
	public CoordinatorLoginController(SchoolRepositoryUserDetailsService schoolService,PasswordEncoder passwordEncoder,
			@Qualifier("SchoolAuthentiactionManager") AuthenticationManager authManager,LecturerRepositoryUserDetailsService lecturerService) {
		this.schoolService=schoolService;
		this.passwordEncoder=passwordEncoder;
		this.authManager=authManager;
		this.lecturerService=lecturerService;
	}
	@GetMapping("/login")
	public String login(Model model){
		model.addAttribute("authentication", "");
		return "/coordinator/login";
	}
	@PostMapping("/login")
	public String login(HttpServletRequest req,HttpSession session,Model model,@RequestParam("username") String username,
			@RequestParam("password") String password) {
		School school=this.schoolService.findByUsername(username);
		if(school==null) {
			model.addAttribute("authentication", "Incorrect username or password");
			return "/coordinator/login";
		}
		else {
			if(this.passwordEncoder.matches(password, school.getPassword())) {
				model.addAttribute(ModelAttributes.SCHOOL.toString(),school);
				model.addAttribute("unapprovedLecturers", this.lecturerService.getUnapprovedLecturers(school));
				model.addAttribute("activateLecturers", new ArrayList<Lecturer>());
				session.setAttribute(ModelAttributes.SCHOOL.toString(), school);
				session.setMaxInactiveInterval(-1);
				authenticate(req,username,password);
				return "/coordinator/home";
			}else {
				model.addAttribute("authentication", "Incorrect username or password");
				return "/coordinator/login";
			}
		}
	}
	public void authenticate(HttpServletRequest req, String user, String pass) {
		UsernamePasswordAuthenticationToken authReq
	      = new UsernamePasswordAuthenticationToken(user, pass);
	    Authentication auth = authManager.authenticate(authReq);
	     
	    SecurityContext sc = SecurityContextHolder.getContext();
	    sc.setAuthentication(auth);
	    HttpSession session = req.getSession(true);
	    session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, sc);
	}
	@GetMapping("/logout")
	public String logout(HttpSession session,Model model,HttpServletRequest request){
		SecurityContext sc = SecurityContextHolder.getContext();
		sc.getAuthentication().setAuthenticated(false);
		session.invalidate();
		for(Cookie cookie:request.getCookies()) {
			cookie.setMaxAge(0);
		}
		model.addAttribute("authentication", "");
		return "redirect:/coordinator/login";
	}
}
