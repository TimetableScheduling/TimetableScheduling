package com.timetableScheduler.controllers;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.hibernate.Hibernate;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.context.HttpSessionSecurityContextRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;

import ch.qos.logback.classic.Logger;

@Controller
@RequestMapping(path="/lecturer")
public class LecturerLoginController {
	private LecturerRepositoryUserDetailsService lecturerService;
	private PasswordEncoder passwordEncoder;
	private AuthenticationManager authManager;
	org.slf4j.Logger logger = LoggerFactory.getLogger(LecturerLoginController.class);
	@Autowired
	public LecturerLoginController(LecturerRepositoryUserDetailsService lecturerService,
			PasswordEncoder passwordEncoder,@Qualifier("LecturerAuthentiactionManager") AuthenticationManager authManager) {
		this.lecturerService=lecturerService;
		this.passwordEncoder=passwordEncoder;
		this.authManager=authManager;
	}
	@GetMapping("/login")
	public String login(Model model) {
		model.addAttribute("authentication", "");
		return "/lecturer/login";
	}
	@PostMapping("/login")
	public String authenticate(HttpServletRequest req,HttpSession session,
			Model model,@RequestParam("username") String username,
			@RequestParam("password") String password) {
		logger.info("letu");
		Lecturer lecturer=this.lecturerService.findByUsername(username);
		if(lecturer==null) {
			model.addAttribute("authentication", "Incorrect username or password");
			return "/lecturer/login";
		}else {
			Hibernate.initialize(lecturer.getCouldTeache());
			logger.info(lecturer.toString());
			if(this.passwordEncoder.matches(password, lecturer.getPassword())) {
				if(lecturer.isApproved()==false) {
					model.addAttribute("authentication", "Account awaits confirmation");
					return "/lecturer/login";
				}
				model.addAttribute(ModelAttributes.LECTURER.toString(),lecturer);
				session.setAttribute(ModelAttributes.LECTURER.toString(), lecturer);
				logger.info("before authen");
				session.setMaxInactiveInterval(-1);
				authenticate(req,username,password);
				return "redirect:/lecturer/editprofile";
			}else {
				model.addAttribute("authentication", "Incorrect username or password");
				return "/lecturer/login";
			}
		}
	}
	public void authenticate(HttpServletRequest req, String user, String pass) {
		UsernamePasswordAuthenticationToken authReq
	      = new UsernamePasswordAuthenticationToken(user, pass);
		//logger.debug(authReq.toString());
	    Authentication auth = authManager.authenticate(authReq);
	    //logger.info(auth.toString());
	    SecurityContext sc = SecurityContextHolder.getContext();
	    sc.setAuthentication(auth);
	    HttpSession session = req.getSession(true);
	    //logger.info(session.toString());
	    session.setAttribute(HttpSessionSecurityContextRepository.SPRING_SECURITY_CONTEXT_KEY, sc);
	}
	@GetMapping("/logout")
	public String logout(HttpSession session,Model model,HttpServletRequest request) {
		SecurityContext sc = SecurityContextHolder.getContext();
		sc.getAuthentication().setAuthenticated(false);
		session.invalidate();
		for(Cookie cookie:request.getCookies()) {
			cookie.setMaxAge(0);
		}
		model.addAttribute("authentication", "");
		return "redirect:/lecturer/login";
	}
}
