package com.timetableScheduler.controllers;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping
public class ErrorController implements org.springframework.boot.web.servlet.error.ErrorController{
	
	Logger logger = LoggerFactory.getLogger(ErrorController.class);
	
	public ErrorController() {
		logger.info("ErrorController invoked");
	}
	@GetMapping("/error")
    public String renderErrorPage(HttpServletRequest httpRequest,Model model) {
         
        int httpErrorCode = getErrorCode(httpRequest);
 
        switch (httpErrorCode) {
            case 400: 
            case 404:{
                model.addAttribute("type", "Http Error Code: "+httpErrorCode);
                model.addAttribute("message", "Are you sure you typed the correct URL?");
                break;
            }
            case 401:
            case 403:{
                model.addAttribute("type", "Http Error Code: "+httpErrorCode);
                model.addAttribute("message", "The page seems to be off limits");
                break;
            }
            default: {
                model.addAttribute("type", "Http Error Code: "+httpErrorCode);
                model.addAttribute("message", "Something Unexpected happened.");
                break;
            }
        }
        return "error";
    }
     
    private int getErrorCode(HttpServletRequest httpRequest) {
        return (Integer) httpRequest
          .getAttribute("javax.servlet.error.status_code");
    }
	@Override
	public String getErrorPath() {
		return "/error";
	}
}
