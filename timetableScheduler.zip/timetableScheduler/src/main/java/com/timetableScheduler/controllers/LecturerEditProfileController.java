package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.School;
import com.timetableScheduler.services.CoursesRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;

@Controller
@RequestMapping("/lecturer")
public class LecturerEditProfileController {
	private LecturerRepositoryUserDetailsService lecturerService;
	private SchoolRepositoryUserDetailsService schoolService;
	private CoursesRepositoryService courseService;
	private static List<Course> courseCouldBeTaughtBy;
	private Logger logger = LoggerFactory.getLogger(LecturerEditProfileController.class);
	@Autowired
	public LecturerEditProfileController(LecturerRepositoryUserDetailsService lecturerService,
			SchoolRepositoryUserDetailsService schoolService,CoursesRepositoryService courseService) {
		this.lecturerService=lecturerService;
		this.schoolService=schoolService;
		this.courseService=courseService;
	}
	@GetMapping("/editprofile")
	public String editMyProfile(Model model,HttpSession session) {
		Lecturer lecturer=(Lecturer)session.getAttribute(ModelAttributes.LECTURER.toString());
		if(lecturer==null) {
			model.addAttribute("authentication", "Please login again");
			return "/lecturer/login";
		}
		courseCouldBeTaughtBy=this.courseService.getCourseCouldTaughtBy(lecturer);
		model.addAttribute(ModelAttributes.LECTURER.toString(), lecturer);
		School school= this.schoolService.findById(lecturer.getSchool().getSchoolID());
		model.addAttribute("edit", true);
		model.addAttribute("subscribingSchool", school);
		return "/lecturer/signup";
	}
	@PostMapping("/submiteditted")
	public String submitEdited(Model model,HttpSession session,@ModelAttribute("school") Lecturer lecturer,
			HttpServletRequest request) {
		Lecturer insessionUser=(Lecturer)session.getAttribute(ModelAttributes.LECTURER.toString());
		insessionUser=this.lecturerService.findById(insessionUser.getLecturerNo());
		if(insessionUser==null) {
			model.addAttribute("authentication", "Please login again");
			return "/lecturer/login";
		}
		insessionUser.setFirstName(lecturer.getFirstName());
		insessionUser.setMiddleName(lecturer.getMiddleName());
		insessionUser.setLastName(lecturer.getLastName());
		insessionUser.setUsername(lecturer.getUsername());
		insessionUser.setEducationLevel(lecturer.getEducationLevel()+" in "+lecturer.getDegree());
		String[] addedCourses=request.getParameterValues("couldTeacheCourse");
		ArrayList<Course> addCourseObjects=new ArrayList<>();
		if(addedCourses!=null) {
			for(String addedCourseIds:addedCourses) {
				Course addedCourse=this.courseService.findById(Integer.parseInt(addedCourseIds));
				addedCourse.getAbleTeachers().add(insessionUser);
				insessionUser.getCouldTeache().add(addedCourse);
				addCourseObjects.add(addedCourse);
			}
			this.courseService.save(addCourseObjects);
		}
		Lecturer newLecturer=this.lecturerService.save(insessionUser);
		logger.info(newLecturer.toString());
		session.setAttribute(ModelAttributes.LECTURER.toString(), newLecturer);
		return "redirect:/lecturer/editprofile";
	}
	public static boolean isCourseAlreadyAdded(int id) {
		for(Course course:courseCouldBeTaughtBy) {
			if(course.getCourseNo()==id) {
				return true;
			}
		}
		return false;
	}
}
