package com.timetableScheduler.controllers;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.PeriodRepositoryService;
import com.timetableScheduler.services.SectionRepositoryService;

@Controller
@RequestMapping(path="/coordinator")
public class CoordinatorSlotSuggestionController {
	private PeriodRepositoryService periodService;
	private LecturerRepositoryUserDetailsService lecturerService;
	private ClassroomRepositoryService classroomService;
	private SectionRepositoryService sectionService;
	org.slf4j.Logger  logger = LoggerFactory.getLogger(CoordinatorSlotSuggestionController.class);
	
	@Autowired
	public CoordinatorSlotSuggestionController(PeriodRepositoryService periodService,ClassroomRepositoryService classroomService,
			LecturerRepositoryUserDetailsService lecturerService,SectionRepositoryService sectionService) {
		this.classroomService=classroomService;
		this.sectionService=sectionService;
		this.lecturerService=lecturerService;
		this.periodService=periodService;
	}
	
	@GetMapping("/slotsuggestion")
	public String slotSuggestion() {
		return "/coordinator/slotsuggestion";
	}
	
	@PostMapping("/suggestslot")
	@ResponseBody
	public ArrayList<Integer> suggestSlot(HttpServletRequest request) {
		/* Constraints: unchanged: section,course,lecturer and classroom
		 * 				change:period
		 * -the lecturer must not have class at the new period and the period should be preferred by him
		 * -the section must not have class at the new period and should be preferred by them 
		 * -the classroom must not be occupied in the new period
		 * */
		Classroom classroom=this.classroomService.findById(Integer.parseInt(request.getParameter("slotClassroomId")));
		Period period=this.periodService.findById(Integer.parseInt(request.getParameter("slotPeriodId"))).get();
		Lecturer lecturer=this.lecturerService.findById(Integer.parseInt(request.getParameter("slotLecturerId")));
		Section section=this.sectionService.findById(Integer.parseInt(request.getParameter("slotSectionId")));
		return getAlternativeFor(classroom,period,lecturer,section);
	}
	private ArrayList<Integer> getAlternativeFor(Classroom classroom,Period period,Lecturer lecturer,Section section){
		List<Period> solution=getPeriodsSatifyingLeturerConstraint(lecturer);
		solution.remove(period);
		solution=getPeriodsSatisfyingSectionConstraint(section,solution);
		solution=getPeriodsSatisfyingClassroomConstraint(classroom,solution);
		//now if the mandatory constraints are satisfied we can try to accommodate lecturer's periodPreference
		List<Period> optimumSolution=satisfyingPeriodPreferenceOf(lecturer,solution);
		ArrayList<Integer> preferredPeriodsIds=new ArrayList<Integer>();
		if(!optimumSolution.isEmpty()) {
			optimumSolution.forEach(aperiod->preferredPeriodsIds.add(aperiod.getPeriodId()));
			return preferredPeriodsIds;
		}
		solution.forEach(aperiod->preferredPeriodsIds.add(aperiod.getPeriodId()));
		return preferredPeriodsIds;
	}
	@PostMapping("/suggestslot/canBeExchangedWith")
	@ResponseBody
	public String canBeExchangedWith(HttpServletRequest request){
		Classroom classroom=this.classroomService.findById(Integer.parseInt(request.getParameter("slotClassroomId")));
		Period period=this.periodService.findById(Integer.parseInt(request.getParameter("slotPeriodId"))).get();
		Lecturer lecturer=this.lecturerService.findById(Integer.parseInt(request.getParameter("slotLecturerId")));
		Section section=this.sectionService.findById(Integer.parseInt(request.getParameter("slotSectionId")));
		int targetSlotPeriodId=Integer.parseInt(request.getParameter("targetSlotPeriodId"));
		logger.info("it is getting called");
		boolean reply=getAlternativeFor(classroom,period,lecturer,section).contains(targetSlotPeriodId);
		if(reply) return "true";
		else return "false";
	}
	private List<Period> getPeriodsSatifyingLeturerConstraint(Lecturer lecturer){
		List<Period> allPeriods=this.periodService.findAll();
		List<Period> lecturerAssignedAt=this.periodService.whenIsLecturerAssigned(lecturer);
		List<Period> periodsSatisfyingLecturerFreeConstraint=
				allPeriods.stream().filter(aperiod->!lecturerAssignedAt.contains(aperiod)).collect(Collectors.toList());
		return periodsSatisfyingLecturerFreeConstraint;
	}
	private List<Period> getPeriodsSatisfyingSectionConstraint(Section section,List<Period> sofarFiltered){
		List<Period> sectionAssignedAt=this.periodService.whenIsSectionAssigned(section);
		return sofarFiltered.stream().filter(period->!sectionAssignedAt.contains(period)).collect(Collectors.toList());
	}
	private List<Period> getPeriodsSatisfyingClassroomConstraint(Classroom classroom,List<Period> sofarFiltered){
		List<Period> classroomOccupiedAt=this.periodService.whenIsClassroomOccupied(classroom);
		return sofarFiltered.stream().filter(period->!classroomOccupiedAt.contains(period)).collect(Collectors.toList());
	}
	private List<Period> satisfyingPeriodPreferenceOf(Lecturer lecturer,List<Period> sofarFiltered){
		List<Period> periodPreferenceOf=this.periodService.getPreferenceOf(lecturer);
		return sofarFiltered.stream().filter(period->periodPreferenceOf.contains(period)).collect(Collectors.toList());
	}
}
