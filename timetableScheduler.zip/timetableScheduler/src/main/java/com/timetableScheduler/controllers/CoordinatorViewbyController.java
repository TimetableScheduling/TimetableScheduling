package com.timetableScheduler.controllers;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.timetableScheduler.algorithm.TimetableGA;
import com.timetableScheduler.constants.Batch;
import com.timetableScheduler.constants.ModelAttributes;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.models.Slot;
import com.timetableScheduler.services.ClassroomRepositoryService;
import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.PeriodRepositoryService;
import com.timetableScheduler.services.SectionRepositoryService;
import com.timetableScheduler.services.SlotRepositoryService;
import com.timetableScheduler.utility.IterableSessionWrapper;
import com.timetableScheduler.utility.SingleClassSessionWrapper;
import com.timetableScheduler.utility.SlotWrapper;

@Controller
@RequestMapping(path="/coordinator")
public class CoordinatorViewbyController {
	private SectionRepositoryService sectionService;
	private LecturerRepositoryUserDetailsService teacherService;
	private ClassroomRepositoryService classroomRepository;
	private SlotRepositoryService slotService;
	
	org.slf4j.Logger  logger = LoggerFactory.getLogger(CoordinatorViewbyController.class);
	@Autowired
	public CoordinatorViewbyController(SectionRepositoryService sectionService,SlotRepositoryService slotService,
			LecturerRepositoryUserDetailsService teacherService,
			ClassroomRepositoryService classroomRepository) {
		this.slotService=slotService;
		this.sectionService=sectionService;
		this.teacherService=teacherService;
		this.classroomRepository=classroomRepository;
	}
	
	@GetMapping("/viewby")
	public String viewby(Model model) {
		return "/coordinator/viewby";
	}
	
	@PostMapping("/getSchedule")
	public String getSchedule(@RequestParam("whichParty") String whichParty,HttpServletRequest request,
			@RequestParam("timetableOf") String timetableOf,HttpSession session,Model model) {
		ArrayList<SingleClassSessionWrapper> thisSectionsSessions=new ArrayList<>();
		HashMap<Integer,SlotWrapper> slotWrappers=new HashMap<>();
		for (SingleClassSessionWrapper s:thisSectionsSessions.stream().filter(sectionSession->sectionSession.session==0).collect(Collectors.toList()));
		Iterable<Slot> requiredSlot=null;
		if(timetableOf.equals("1")) {
			//Sections
			model.addAttribute("timetableOf", "Sections");
			Section section=this.sectionService.findById(Integer.parseInt(whichParty));
			model.addAttribute("whichParty", Batch.values()[Integer.parseInt(section.getBatch())-1]+" year "+section.getSectionId());
			requiredSlot=this.slotService.findBySection(section);
			for(Slot slot:requiredSlot) {
				Classroom classroom=slot.getClassroom();
				Lecturer lecturer=slot.getLecturer();
				Course course=slot.getCourse();
				String detailedCourseInfo=course.getCourseCode()+"-"+course.getCourseName();
				slotWrappers.put(slot.getPeriod().getPeriodId(),new SlotWrapper(section.getSectionNo(),classroom.getRoomNo(),lecturer.getLecturerNo()));
				thisSectionsSessions.add(new SingleClassSessionWrapper(
						lecturer.getFullName(),classroom.getRoomID(),slot.getPeriod().getPeriodId(),detailedCourseInfo));
			}
		}else if(timetableOf.equals("2")) {
			//lecturer
			model.addAttribute("timetableOf", "Lecturer");
			Lecturer lecturer=this.teacherService.findById(Integer.parseInt(whichParty));
			model.addAttribute("whichParty", lecturer.getFullName());
			requiredSlot=this.slotService.findByLecturer(lecturer);
			for(Slot slot:requiredSlot) {
				Classroom classroom=slot.getClassroom();
				Section section=slot.getSection();
				Course course=slot.getCourse();
				String detailedSectionInfo=Batch.values()[Integer.parseInt(section.getBatch())-1]+" year "+section.getSectionId();
				String detailedCourseInfo=course.getCourseCode()+"-"+course.getCourseName();
				slotWrappers.put(slot.getPeriod().getPeriodId(),new SlotWrapper(section.getSectionNo(),classroom.getRoomNo(),lecturer.getLecturerNo()));
				thisSectionsSessions.add(new SingleClassSessionWrapper(
						detailedSectionInfo,classroom.getRoomID(),slot.getPeriod().getPeriodId(),detailedCourseInfo));
			}
		}else{//if(whichParty.equals("3"))
			//Classroom
			model.addAttribute("timetableOf", "Classrooms");
			Classroom classroom=this.classroomRepository.findById(Integer.parseInt(whichParty));
			model.addAttribute("whichParty", classroom.getRoomID());
			requiredSlot=this.slotService.findByClassroom(classroom);
			for(Slot slot:requiredSlot) {
				Lecturer lecturer=slot.getLecturer();
				Section section=slot.getSection();
				Course course=slot.getCourse();
				String detailedSectionInfo=Batch.values()[Integer.parseInt(section.getBatch())-1]+" year "+section.getSectionId();
				String detailedCourseInfo=course.getCourseCode()+"-"+course.getCourseName();
				slotWrappers.put(slot.getPeriod().getPeriodId(),new SlotWrapper(section.getSectionNo(),classroom.getRoomNo(),lecturer.getLecturerNo()));
				thisSectionsSessions.add(new SingleClassSessionWrapper(
						detailedSectionInfo,lecturer.getFullName(),slot.getPeriod().getPeriodId(),detailedCourseInfo));
			}
		}
		model.addAttribute("classSessions", new IterableSessionWrapper(thisSectionsSessions));
		model.addAttribute("slotWrappers", slotWrappers);
		logger.info(request.getParameter("sourceUrl"));
		return request.getParameter("sourceUrl");
	}
	
	@GetMapping("/viewby/getData/{whichParty}")
	@ResponseBody
	public String[][] getData(@PathVariable("whichParty") String whichParty,HttpSession session) {
		School school=(School)session.getAttribute(ModelAttributes.SCHOOL.toString());
		String[][] data=new String[0][];
		if(school==null) {
			return data;
		}
		if(whichParty.equals("1")) {
			//Sections
			logger.info("Sections requetsed");
			Set<Section> sections=new HashSet<>(this.sectionService.findOnesWithSchedule(school));
			data=new String[sections.size()][2];
			int count=0;
			for(Section section:sections){
				String[] internal=new String[2];
				internal[0]=String.valueOf(section.getSectionNo());
				internal[1]=Batch.values()[Integer.parseInt(section.getBatch())-1]+" year "+section.getSectionId();
				data[count++]=internal;
			}
		}else if(whichParty.equals("2")) {
			//lecturer
			logger.info("leturer requetsed");
			Set<Lecturer> lecturers=new HashSet<>(this.teacherService.findOnesWithSchedule(school));
			data=new String[lecturers.size()][2];
			int count=0;
			for(Lecturer lecturer:lecturers){
				String[] internal=new String[2];
				internal[0]=""+lecturer.getLecturerNo();
				internal[1]=lecturer.getFullName();
				data[count++]=internal;
			}
		}else{
			//Classroom
			logger.info("classroom requetsed");
			Set<Classroom> classrooms=new HashSet<>(this.classroomRepository.findWithPrograms(school));
			data=new String[classrooms.size()][2];
			int count=0;
			for(Classroom classroom:classrooms){
				String[] internal=new String[2];
				internal[0]=""+classroom.getRoomNo();
				internal[1]=classroom.getRoomID();
				data[count++]=internal;
			}
		}
		return data;
	}
}
