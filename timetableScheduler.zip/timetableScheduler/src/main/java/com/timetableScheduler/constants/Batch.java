package com.timetableScheduler.constants;

public enum Batch {
	FIRST_YEAR("1st"),SECOND_YEAR("2nd"),THIRD_YEAR("3rd"),
	FOURTH_YEAR("4th"),FIFTH_YEAR("5th"),SIXTH_YEAR("6th"),SEVENTH_YEAR("7th");
	private String stringForm;
	private Batch(String stringForm) {
		this.stringForm=stringForm;
	}
	@Override
	public String toString() {
		return this.stringForm;
	}
}
