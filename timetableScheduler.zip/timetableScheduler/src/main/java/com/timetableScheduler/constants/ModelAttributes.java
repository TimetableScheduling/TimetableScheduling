package com.timetableScheduler.constants;

public enum ModelAttributes {
	SCHOOL("school"),LECTURER("lecturer");
	private final String stringValue;
	private ModelAttributes(String stringValue) {
		this.stringValue=stringValue;
	}
	@Override
	public String toString() {
		return this.stringValue;
	}
}
