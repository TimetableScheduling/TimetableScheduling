package com.timetableScheduler.constants;


public enum Degree {
	BSC("B.Sc"),MSC("M.Sc"),PHD("Ph.D");
	private String readable;
	private Degree(String stringForm) {
		this.readable=stringForm;
	}
	
	@Override
	public String toString() {
		return this.readable;
	}
}
