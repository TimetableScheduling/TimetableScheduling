package com.timetableScheduler.constants;

public enum Sessions {
	SESSION_I("02:30-04:10"),SESSION_II("04:30-06:10"),SESSION_III("07:30-09:10"),SESSION_VI("09:30-11:10");
	private String readable;
	private Sessions(String readable) {
		this.readable=readable;
	}
	
	@Override
	public String toString() {
		return this.readable;
	}
}
