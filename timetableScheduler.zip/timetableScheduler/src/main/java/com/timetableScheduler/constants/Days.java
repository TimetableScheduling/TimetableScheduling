package com.timetableScheduler.constants;

public enum Days {
	MONDAY("Mon"),TUESDAY("Tue"),
	WEDNESDAY("Wed"),THURSDAY("Thu"),
	FRIDAY("Fri"),SATURDAY("Sat");
	private String readable;
	
	private Days(String readable) {
		this.readable=readable;
	}
	
	@Override
	public String toString() {
		return this.readable;
	}
}
