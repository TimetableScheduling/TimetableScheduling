package com.timetableScheduler.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;

import com.timetableScheduler.services.LecturerRepositoryUserDetailsService;
import com.timetableScheduler.services.SchoolRepositoryUserDetailsService;

@Configuration
public class SecurityConfig{
	@Configuration
	@EnableWebSecurity
	@Order(1)
	public static class LecturerSecurityConfig extends WebSecurityConfigurerAdapter{
		@Autowired
		private LecturerRepositoryUserDetailsService lecturerUserDetailsService;
		@Autowired
		private LecturerAuthenticationProvider lecturerAuthenticationProvider;
		@Bean
		@Override
		public UserDetailsService userDetailsService(){
			return lecturerUserDetailsService;
		}
		@Bean
		public PasswordEncoder passwordEncoder() {
		    return new BCryptPasswordEncoder();
		}
		@Bean("LecturerAuthentiactionManager")
		@Override
		public AuthenticationManager authenticationManagerBean() throws Exception {
		   return super.authenticationManagerBean();
		}
		@Override
		protected void configure(AuthenticationManagerBuilder auth)
		 throws Exception {
			auth.authenticationProvider(lecturerAuthenticationProvider).
			 userDetailsService(lecturerUserDetailsService)
			 .passwordEncoder(passwordEncoder());
		}
		@Bean
		 @Override
		 public UserDetailsService userDetailsServiceBean() throws Exception {
		        return super.userDetailsServiceBean();
		 }
		@Override
		protected void configure(HttpSecurity http) throws Exception{
			http.authorizeRequests().antMatchers("/lecturer/login/**","/lecturer/signup/**","/accessdenied")
			.permitAll().antMatchers("/lecturer/**").authenticated().//hasAuthority("LECTURER").
			and().exceptionHandling().accessDeniedPage("/accessdenied").and().
			logout().logoutUrl("/lecturer/logout").invalidateHttpSession(true);
		}
	}
	@Configuration
	@EnableWebSecurity
	@Order(2)
	public static class SchoolSecurityConfig extends WebSecurityConfigurerAdapter{
		@Autowired
		private SchoolRepositoryUserDetailsService schoolUserDetailsService;
		@Autowired
		private SchoolAuthenticationProvider schoolAuthenticationProvider;
		@Bean
		@Override
		public UserDetailsService userDetailsService(){
			return schoolUserDetailsService;
		}
		@Bean
		public PasswordEncoder passwordEncoder() {
		    return new BCryptPasswordEncoder();
		}
		@Bean("SchoolAuthentiactionManager")
		@Override
		public AuthenticationManager authenticationManagerBean() throws Exception {
		   return super.authenticationManagerBean();
		}
		@Override
		protected void configure(AuthenticationManagerBuilder auth)
		 throws Exception {
			auth.authenticationProvider(schoolAuthenticationProvider)
			 .userDetailsService(schoolUserDetailsService)
			 .passwordEncoder(passwordEncoder());
		}
		@Override
		protected void configure(HttpSecurity http) throws Exception{
			http.authorizeRequests().antMatchers("/coordinator/signup/**","/coordinator/login/**","/accessdenied")
			.permitAll().antMatchers("/coordinator/**").authenticated().//hasAuthority("COORDINATOR").
			and().exceptionHandling().accessDeniedPage("/accessdenied").and().logout().
			logoutUrl("/coordinator/logout").invalidateHttpSession(true);
		}
		@Bean
		@Override
		public UserDetailsService userDetailsServiceBean() throws Exception {
		        return super.userDetailsServiceBean();
		}
	}
}
