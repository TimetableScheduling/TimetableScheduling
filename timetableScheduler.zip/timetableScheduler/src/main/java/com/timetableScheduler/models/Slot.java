package com.timetableScheduler.models;



import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
@Entity
public class Slot {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int slotId;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Section section;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Classroom classroom;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Period period;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Course course;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Lecturer lecturer;
	
	@ManyToOne(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private School school;
	public Slot(Section section,Classroom classroom,Period period,Course course,Lecturer lecturer,School school) {
		this.section=section;
		this.classroom=classroom;
		this.period=period;
		this.course=course;
		this.lecturer=lecturer;
		this.school=school;
	}
	public Slot() {
		
	}
}
