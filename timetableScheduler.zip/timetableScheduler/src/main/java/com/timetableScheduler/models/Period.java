package com.timetableScheduler.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.springframework.data.annotation.Transient;

import com.timetableScheduler.constants.Days;
import com.timetableScheduler.constants.Sessions;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Entity
@Setter
@Getter
public class Period {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int periodId;
	private String periodName;
	@ManyToMany(fetch=FetchType.LAZY)
	private Set<Classroom> assignedClassrooms;
	@ManyToMany(fetch=FetchType.LAZY)
	private Set<Course> assignedCourses;
	@ManyToMany(fetch=FetchType.LAZY)
	private Set<Section> assignedSections;
	@ManyToMany(fetch=FetchType.LAZY)
	private Set<Lecturer> assignedLecturers;
	@ManyToMany(mappedBy="availableAt",fetch=FetchType.LAZY)
	private Set<Lecturer> lecturerPreference;
	@ManyToMany(mappedBy="assignedPeriods",fetch=FetchType.LAZY)
	private Set<Lecturer> lecturerAssignment;
	private Days day;
	private Sessions session;
	@OneToMany(mappedBy="period",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlots;
	
	/* -------------------------ATTENTION--------------------
	 * This class should/will have a private constructor since all the periods are known.
	 * */
	@PrePersist
	public void periodId() {
		this.periodName=this.day+" at "+this.session;
	}
	//private Period() {
		
	//}
}