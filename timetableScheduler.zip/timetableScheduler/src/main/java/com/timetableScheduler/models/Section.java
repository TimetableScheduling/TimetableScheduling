package com.timetableScheduler.models;

import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
public class Section {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int sectionNo;
	
	//from view
	@NotBlank(message = "name is mandatory")
	private String sectionId;
	
	//from view
	@Min(value = 0, message = "capacity must be greater than 0")
	private int sectionSize;
	
	//from view
	private String batch;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Classroom> assignedAt;
	
	//from view
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Course> coursesTaking;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Classroom> classroomPreference;
	
	@ManyToMany(mappedBy="assignedSections",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Period> hasClassesAt;
	
	@ManyToMany(mappedBy="assignedSections",fetch=FetchType.LAZY)
	private Set<Lecturer> assignedLecturers;
	
	@ManyToOne(fetch=FetchType.LAZY)
    @JoinColumn(name="school_id", nullable=false)
    private School school;
	
	@OneToMany(mappedBy="section",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlots;
	
	
	public boolean isPreferred(Classroom classroom) {
		return this.classroomPreference.contains(classroom);
	}
}