package com.timetableScheduler.models;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
public class Course implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int courseNo;
	
	//from view
	private String courseCode;
	
	@ManyToMany(mappedBy = "couldTeache",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Lecturer> ableTeachers;
	
	@ManyToMany(mappedBy = "coursesTeaching",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Lecturer> teachingTeachers;
	
	//from view
	private String courseName;
	
	//from view
	private String creditHours;

	private String numberOfLabClasses;
	
	//from view
	private String batch;
	
	private String numberOfLectureClasses;
	
	//from view
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Section> takerSection;
	
	@ManyToMany(mappedBy="assignedCourses",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Period> timeCourseGiven;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Classroom> givenWhere;
	
	//from view
	@ManyToOne
    @JoinColumn(name="school_id", nullable=false)
    private School school;
	
	@OneToMany(mappedBy="course",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlots;
}