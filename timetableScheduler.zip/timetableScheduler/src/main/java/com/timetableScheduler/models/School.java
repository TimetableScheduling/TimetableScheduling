package com.timetableScheduler.models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedAttributeNode;
import javax.persistence.NamedEntityGraph;
import javax.persistence.NamedSubgraph;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.PreUpdate;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;
import org.hibernate.annotations.LazyCollection;
import org.hibernate.annotations.LazyCollectionOption;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import com.timetableScheduler.controllers.CoordinatorEditProfileController;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
public class School implements UserDetails{
	private static final long serialVersionUID = 822211676581817385L;
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int schoolID;
	//from view
	
	private String username;
	//from view
	
	@OneToMany(mappedBy="school",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Classroom> classrooms=new HashSet<>();
	
	@Transient
	private ArrayList<Classroom> listClassrooms;
	//from view
	
	@OneToMany(mappedBy="school",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Course> courses=new HashSet<>();
	
	@Transient
	private ArrayList<Course> listCourses;
	
	//from view
	@OneToMany(mappedBy="school",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Lecturer> lecturers = new HashSet<>();
	
	@Transient
	private ArrayList<Lecturer> listLecturers;
	
	//from view
	@OneToMany(mappedBy="school",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Section> sections = new HashSet<>();
	
	@Transient
	private ArrayList<Section> listSections;
	
	@OneToMany(mappedBy="school",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlots;
	
	@Transient
	private ArrayList<Slot> listSlots;
	
	//from view
	private String password;
	
	//from view
	private String schoolName;
	
	//private boolean needsUpdate;
	@PrePersist
	public void setDetails() {
		SchoolHelper.logger.warn("prepersiste");
		listClassrooms.forEach(classroom->classroom.setSchool(this));
		listCourses.forEach(course->course.setSchool(this));
		listSections.forEach(section->section.setSchool(this));
		classrooms.addAll(listClassrooms);//updateClassroom();
		courses.addAll(listCourses);//updateCourses();
		sections.addAll(listSections);//updateSection();
		for(Section section:sections) {
			SchoolHelper.logger.warn("from school prepersist "+section.toString());
		}
	}
	
	
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_COORDINATOR"));
	}
	
	@Override
	public String getUsername() {
		return username;
	}
	
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	
	@Override
	public boolean isEnabled() {
		return true;
	}
	public static class SchoolHelper{
		private static Logger logger = LoggerFactory.getLogger(School.class);
	}
}