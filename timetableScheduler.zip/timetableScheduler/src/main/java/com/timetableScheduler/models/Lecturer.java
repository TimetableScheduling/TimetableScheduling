package com.timetableScheduler.models;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.PrePersist;
import javax.persistence.Transient;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import com.timetableScheduler.constants.Degree;
import com.timetableScheduler.repositories.LecturerRepository;
import com.timetableScheduler.repositories.SchoolRepository;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
public class Lecturer implements UserDetails{
	private static final long serialVersionUID = -819430016291567467L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int lecturerNo;
	
	private String firstName;
	
	private String middleName;
	
	private String lastName;	
	
	private String lecturerId;
	
	private int numberOfPeriodsWillingToTeach;
	//from view
	@Transient
	private String fieldsOfStudy;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Period> assignedPeriods;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Section> assignedSections;
	@Transient
	private ArrayList<Section> listAssignedSections;
	//from view
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Period> availableAt;
	
	@ManyToMany(fetch=FetchType.LAZY)
	@JoinTable(
			  name = "course_teaching", 
			  joinColumns = @JoinColumn(name = "lecturer_id"), 
			  inverseJoinColumns = @JoinColumn(name = "course_id"))
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Course> coursesTeaching;
	
	@Transient
	private ArrayList<Course> listCoursesTeaching;
	
	//from view
	@ManyToMany(fetch=FetchType.LAZY)
	@JoinTable(
			  name = "could_teach_course", 
			  joinColumns = @JoinColumn(name = "lecturer_id"), 
			  inverseJoinColumns = @JoinColumn(name = "course_id"))
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Course> couldTeache;
	
	@Transient
	private ArrayList<Course> listCouldTeache;
	
	@ManyToMany(mappedBy="whoTeachHere",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Classroom> teachesAt;
	
	@Transient
	private ArrayList<Classroom> listTeachesAt;
	
	@OneToMany(mappedBy="lecturer",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlot;
	
	@Transient
	private ArrayList<Slot> listSlots;
	
	private String educationLevel;
	
	private String password;
	
	private String username;
	
	private boolean approved;
	
	@ManyToOne
    @JoinColumn(name="school_id", nullable=false)
	@Cascade(CascadeType.SAVE_UPDATE)
    private School school;
	
	@PrePersist
	public void studies() {
		educationLevel+=" in "+fieldsOfStudy;
	}
	
	public String getEthiopianName() {
		return this.firstName+" "+this.middleName;
	}
	
	public String getFullName(){
		return this.firstName+" "+this.middleName+" "+this.lastName;
	}
	
	public String getDegree() {
		String[] values=this.educationLevel.split("in");
		return values[0].trim();
	}
	
	public String getLearnedCourse() {
		String[] values=this.educationLevel.split(" in ");
		return values[1].trim();
	}
	public boolean isCourseAlreadyAdded(int id) {
		for(Course course:couldTeache) {
			if(course.getCourseNo()==id) {
				return true;
			}
		}
		return false;
	}
	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		return Arrays.asList(new SimpleGrantedAuthority("ROLE_LECTURER"));
	}
	
	@Override
	public boolean isAccountNonExpired() {
		return true;
	}
	
	@Override
	public boolean isAccountNonLocked() {
		return true;
	}
	
	@Override
	public boolean isCredentialsNonExpired() {
		return true;
	}
	
	@Override
	public boolean isEnabled() {
		return true;
	}
}