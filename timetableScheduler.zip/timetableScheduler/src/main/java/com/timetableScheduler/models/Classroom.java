package com.timetableScheduler.models;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Entity
@Setter
@Getter
public class Classroom {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private int roomNo;
	@ManyToMany(mappedBy="assignedClassrooms",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Period> busyAt;
	@ManyToMany(mappedBy="givenWhere",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Course> coursesGiven;
	@ManyToMany(fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Lecturer> whoTeachHere;
	//from view
	@Min(value = 0, message = "capacity must be greater than 0")
	private int capacity;
	//from view
	private String roomID;
	@ManyToMany(mappedBy="assignedAt",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Section> assignedSections;
	@ManyToMany(mappedBy="classroomPreference",fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Section> preferringSections;
	@ManyToOne
    @JoinColumn(name="school_id", nullable=false)
    private School school;
	@OneToMany(/*mappedBy="classroom",*/fetch=FetchType.LAZY)
	@Cascade(CascadeType.SAVE_UPDATE)
	private Set<Slot> containingSlots;
}