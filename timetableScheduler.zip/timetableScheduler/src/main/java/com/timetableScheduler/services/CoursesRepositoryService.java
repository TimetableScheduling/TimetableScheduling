package com.timetableScheduler.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.repositories.CourseRepository;

@Service
public class CoursesRepositoryService {
	private CourseRepository courseRepository;
	@Autowired
	public CoursesRepositoryService(CourseRepository courseRepository) {
		this.courseRepository=courseRepository;
	}
	public Iterable<Course> findAll(){
		return this.courseRepository.findAll();
	}
	public Course findByCrossSection(Lecturer lecturer,Period period) {
		return this.courseRepository.findByTeachingTeachersContainsAndTimeCourseGivenContains(lecturer, period);
	}
	public Course findById(int courseId) {
		return this.courseRepository.findById(courseId).get();
	}
	public ArrayList<Course> findBySchool(School school){
		return this.courseRepository.findBySchool(school);
	}
	public List<Course> findCoursesTakenBy(Section section){
		return this.courseRepository.findByTakerSectionIn(section);
	}
	
	public Course save(Course entity) {
		return this.courseRepository.save(entity);
	}
	
	public void save(ArrayList<Course> entities) {
		 this.courseRepository.saveAll(entities);
	}
	
	public List<Course> getCourseCouldTaughtBy(Lecturer lecturer){
		return this.courseRepository.findByAbleTeachersContains(lecturer);
	}
}
