package com.timetableScheduler.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.repositories.PeriodRepository;

@Service
public class PeriodRepositoryService {
	private PeriodRepository periodRepository;
	@Autowired
	public PeriodRepositoryService(PeriodRepository periodRepository) {
		this.periodRepository=periodRepository;
	}
	public List<Period> findAll(){
		return (List<Period>) this.periodRepository.findAll();
	}
	public Optional<Period> findById(Integer id) {
		return this.periodRepository.findById(id);
	}
	public List<Period> getPreferenceOf(Lecturer lecturer){
		return this.periodRepository.findByLecturerPreferenceContains(lecturer);
	}
	public Period save(Period period) {
		return this.periodRepository.save(period);
	}
	public void save(ArrayList<Period> entities) {
		this.periodRepository.saveAll(entities);
	}
	public List<Period> whenIsLecturerAssigned(Lecturer lecturer){
		return this.periodRepository.findByLecturerAssignmentContains(lecturer);
	}
	public List<Period> whenIsSectionAssigned(Section section) {
		return this.periodRepository.findByAssignedSectionsContains(section);
	}
	public List<Period> whenIsClassroomOccupied(Classroom classroom){
		return this.periodRepository.findByAssignedClassroomsContains(classroom);
	}
}
