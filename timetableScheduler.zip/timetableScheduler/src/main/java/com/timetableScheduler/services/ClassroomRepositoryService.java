package com.timetableScheduler.services;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.repositories.ClassroomRepository;

@Service
public class ClassroomRepositoryService {
	private ClassroomRepository classroomRepository;
	@Autowired
	public ClassroomRepositoryService(ClassroomRepository classroomRepository) {
		this.classroomRepository=classroomRepository;
	}
	public Classroom findByCrossSection(Lecturer lecturer,Period period) {
		return this.classroomRepository.findByWhoTeachHereContainsAndBusyAtContains(lecturer, period);
	}
	public Classroom findById(int classroomId) {
		return this.classroomRepository.findById(classroomId).get();
	}
	public ArrayList<Classroom> findByShool(School school){
		return this.classroomRepository.findBySchool(school);
	}
	public Iterable<Classroom> findAll(){
		return this.classroomRepository.findAll();
	}
	public ArrayList<Classroom> findWithPrograms(School school){
		return this.classroomRepository.findBySchoolAndContainingSlotsNotNull(school);
	}
	public List<Classroom> getPreferenceOf(Section section){
		return this.classroomRepository.findByPreferringSectionsContains(section);
	}
	public Classroom save(Classroom entity) {
		return this.classroomRepository.save(entity);
	}
	public void save(ArrayList<Classroom> entities) {
		 this.classroomRepository.saveAll(entities);
	}
}
