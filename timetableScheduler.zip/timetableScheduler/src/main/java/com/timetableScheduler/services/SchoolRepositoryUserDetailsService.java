package com.timetableScheduler.services;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.School;
import com.timetableScheduler.repositories.SchoolRepository;

@Service
public class SchoolRepositoryUserDetailsService implements UserDetailsService{

	private SchoolRepository schoolRepository;
	@Autowired
	public SchoolRepositoryUserDetailsService(SchoolRepository schoolRepository) {
		this.schoolRepository=schoolRepository;
	}
	@Override
	public UserDetails loadUserByUsername(String username){
		return this.schoolRepository.findByUsername(username);
	}
	public School findByUsername(String username) {
		return this.schoolRepository.findByUsername(username);
	}
	public School save(School school) {
		return this.schoolRepository.save(school);
	}
	public School getSchoolAccount(String username,String password) {
		return this.schoolRepository.findByUsernameAndPassword(username, password);
	}
	public Iterable<School> getAllSchools(){
		return this.schoolRepository.findAll();
	}
	public School findById(int id) {
		return this.schoolRepository.findById(id).get();
	}
}
