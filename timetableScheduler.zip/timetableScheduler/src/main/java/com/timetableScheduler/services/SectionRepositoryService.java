package com.timetableScheduler.services;

import java.util.ArrayList;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.repositories.SectionRepository;

@Service
public class SectionRepositoryService {
	private SectionRepository sectionRepository;
	@Autowired
	public SectionRepositoryService(SectionRepository sectionRepository) {
		this.sectionRepository=sectionRepository;
	}
	
	public Section findByCrossSection(Period period,Lecturer lecturer) {
		return this.sectionRepository.findByHasClassesAtContainsAndAssignedLecturersContains(period, lecturer);
	}
	
	public Section findById(int sectionId) {
		return this.sectionRepository.findById(sectionId).get();
	}
	
	public Iterable<Section> findAll(){
		return this.sectionRepository.findAll();
	}
	
	public ArrayList<Section> findBySchoolAll(School school){
		return this.sectionRepository.findBySchool(school);
	}
	
	public ArrayList<Section> findOnesWithSchedule(School school){
		return this.sectionRepository.findBySchoolAndContainingSlotsNotNull(school);
	}
	
	public Section save(Section entity) {
		return this.sectionRepository.save(entity);
	}
	
	public void save(ArrayList<Section> entities) {
		this.sectionRepository.saveAll(entities);
	}
}
