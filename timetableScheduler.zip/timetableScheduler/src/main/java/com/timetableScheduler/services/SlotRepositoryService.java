package com.timetableScheduler.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.models.Slot;
import com.timetableScheduler.repositories.SlotRepository;

@Service
public class SlotRepositoryService {
	private SlotRepository slotRepository;
	@Autowired
	public SlotRepositoryService(SlotRepository slotRepository) {
		this.slotRepository=slotRepository;
	}
	public Slot save(Slot slot) {
		return this.slotRepository.save(slot);
	}
	public Slot findByPeriodAndSection(Period period,Section section){
		return this.slotRepository.findByPeriodAndSection(period, section);
	}
	public Slot findByPeriodAndClassroom(Period period,Classroom classroom){
		return this.slotRepository.findByPeriodAndClassroom(period, classroom);
	}
	public Slot findByPeriodAndLectuer(Period period,Lecturer lecturer){
		return this.slotRepository.findByPeriodAndLecturer(period, lecturer);
	}
	public Iterable<Slot> findBySection(Section section){
		return this.slotRepository.findBySection(section);
	}
	public Iterable<Slot> findByLecturer(Lecturer lecturer){
		return this.slotRepository.findByLecturer(lecturer);
	}
	public Iterable<Slot> findByClassroom(Classroom classroom){
		return this.slotRepository.findByClassroom(classroom);
	}
	public ArrayList<Slot> findBySchool(School school){
		return this.slotRepository.findBySchool(school);
	}
	public void delete(Slot slot) {
		this.slotRepository.delete(slot);
	}
	
	public void save(ArrayList<Slot> entities) {
		this.slotRepository.saveAll(entities);
	}
}
