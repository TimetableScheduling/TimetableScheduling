package com.timetableScheduler.services;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.timetableScheduler.controllers.LecturerLoginController;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.School;
import com.timetableScheduler.repositories.LecturerRepository;

@Service
public class LecturerRepositoryUserDetailsService implements UserDetailsService{
	private LecturerRepository lecturerRepository;
	org.slf4j.Logger logger = LoggerFactory.getLogger(LecturerLoginController.class);
	@Autowired
	public LecturerRepositoryUserDetailsService(LecturerRepository lecturerRepository) {
		this.lecturerRepository=lecturerRepository;
	}
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException{
		Lecturer lecturer=this.lecturerRepository.findByUsername(username);
		if(lecturer!=null) {
			return lecturer;
		}
		throw new UsernameNotFoundException("username "+username+" not found");
	}
	public Lecturer save(Lecturer lecturer) {
		return this.lecturerRepository.save(lecturer);
	}
	public Lecturer findByUsername(String username) {
		return this.lecturerRepository.findByUsername(username);
	}
	public Lecturer findById(int lecturerId) {
		return this.lecturerRepository.findById(lecturerId).get();
	}
	public long count() {
		return this.lecturerRepository.count();
	}
	
	public ArrayList<Lecturer> getUnapprovedLecturers(School school){
		return this.lecturerRepository.findBySchoolAndApproved(school, false);
	}
	
	public Iterable<Lecturer> findAll(){
		return this.lecturerRepository.findAll();
	}
	
	public ArrayList<Lecturer> findBySchoolAll(School school){
		return this.lecturerRepository.findBySchool(school);
	}
	
	public ArrayList<Lecturer> findOnesWithSchedule(School school){
		return this.lecturerRepository.findBySchoolAndContainingSlotNotNull(school);
	}
	
	public List<Lecturer> getLecturersThatCouldTeach(Course course){
		return this.lecturerRepository.findByCouldTeacheContains(course);
	}
	
	public void save(ArrayList<Lecturer> entities) {
		 this.lecturerRepository.saveAll(entities);
	}
}
