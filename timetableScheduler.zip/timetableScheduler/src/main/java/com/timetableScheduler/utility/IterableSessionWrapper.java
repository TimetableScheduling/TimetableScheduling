package com.timetableScheduler.utility;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class IterableSessionWrapper {
	public ArrayList<SingleClassSessionWrapper> sessionWrapper;
	private List<SingleClassSessionWrapper> sessionIweekDayValues;
	private List<SingleClassSessionWrapper> sessionIIweekDayValues;
	private List<SingleClassSessionWrapper> sessionIIIweekDayValues;
	private List<SingleClassSessionWrapper> sessionIVweekDayValues;
	
	public IterableSessionWrapper(ArrayList<SingleClassSessionWrapper> sessionWrapper) {
		this.sessionWrapper=sessionWrapper;
		this.sessionIweekDayValues=this.sessionWrapper.stream().filter(session->session.session==0).collect(Collectors.toList());
		this.sessionIIweekDayValues=this.sessionWrapper.stream().filter(session->session.session==1).collect(Collectors.toList());
		this.sessionIIIweekDayValues=this.sessionWrapper.stream().filter(session->session.session==2).collect(Collectors.toList());
		this.sessionIVweekDayValues=this.sessionWrapper.stream().filter(session->session.session==3).collect(Collectors.toList());
	}
	public SingleClassSessionWrapper getByPeriod(int day,int period) {
		List<SingleClassSessionWrapper> selected=this.sessionWrapper.stream().
				filter(session->session.day==day && session.session==period).collect(Collectors.toList());
		if(selected.isEmpty()) {
			return null;
		}
		return selected.get(0);
	}
	public SingleClassSessionWrapper getByPeriod(int periodId) {
		List<SingleClassSessionWrapper> selected=this.sessionWrapper.stream().
				filter(session->session.periodId==periodId).collect(Collectors.toList());
		if(selected.isEmpty()) {
			return null;
		}
		return selected.get(0);
	}
}
