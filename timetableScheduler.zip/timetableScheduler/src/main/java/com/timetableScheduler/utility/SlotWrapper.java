package com.timetableScheduler.utility;

import lombok.Data;

@Data
public class SlotWrapper {
	private int sectionId;
	private int classroomId;
	private int periodId;
	private int courseId;
	private int lecturerId;
	public SlotWrapper(int sectionId,int classroomId,int periodId,int courseId,int lecturerId) {
		this.sectionId=sectionId;
		this.classroomId=classroomId;
		this.periodId=periodId;
		this.courseId=courseId;
		this.lecturerId=lecturerId;
	}
	public SlotWrapper(int sectionId,int classroomId,int lecturerId) {
		this.sectionId=sectionId;
		this.classroomId=classroomId;
		this.lecturerId=lecturerId;
	}
}
