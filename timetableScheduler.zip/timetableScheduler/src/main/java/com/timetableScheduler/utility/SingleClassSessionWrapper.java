package com.timetableScheduler.utility;

import com.timetableScheduler.models.Period;

public class SingleClassSessionWrapper{
	public String section;
	public String classroom;
	public int day;
	public int session;
	public int periodId;
	public String course;
	public String lecturerFullName;
	public SingleClassSessionWrapper(String section,String classroom,int day,int session,String course) {
		this.section=section;
		this.classroom=classroom;
		this.day=day;
		this.session=session;
		this.course=course;
		this.lecturerFullName="";
	}
	public SingleClassSessionWrapper(String section,String classroom,int periodId,String course) {
		this.section=section;
		this.classroom=classroom;
		this.periodId=periodId;
		this.course=course;
		this.lecturerFullName="";
	}
	public SingleClassSessionWrapper(String section,String classroom,int day,int session,String course,String lecturerFullName) {
		this.section=section;
		this.classroom=classroom;
		this.day=day;
		this.session=session;
		this.course=course;
		this.lecturerFullName=lecturerFullName;
	}
}
