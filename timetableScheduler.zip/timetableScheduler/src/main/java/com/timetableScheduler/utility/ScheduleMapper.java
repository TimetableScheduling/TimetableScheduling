package com.timetableScheduler.utility;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@RequiredArgsConstructor
public class ScheduleMapper {
	private final String lecturerFullName;
	private final String sectionName;
	private final String courseName;
	private final String classroomName;
}
