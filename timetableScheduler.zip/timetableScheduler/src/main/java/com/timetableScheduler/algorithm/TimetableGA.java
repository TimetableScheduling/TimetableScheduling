/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.slf4j.LoggerFactory;

import com.timetableScheduler.constants.Days;
import com.timetableScheduler.constants.Sessions;
import com.timetableScheduler.controllers.LecturerLoginController;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.School;
import com.timetableScheduler.utility.SingleClassSessionWrapper;
import com.timetableScheduler.utility.SlotWrapper;


public class TimetableGA {
	public static volatile double percent=-1;
	static org.slf4j.Logger  logger = LoggerFactory.getLogger(TimetableGA.class);
    //public static ArrayList<SlotWrapper> generateForSchool(School school) {
	public static ArrayList<SlotWrapper> generateForSchool(HashMap<Integer,Integer[]> classroomPreference,
			HashMap<Integer,Integer[]> periodPreference,Room[] rooms,
			Lecturer[] lecturers,Course[] courses,Section[] sections) {
    	// Get a Timetable object with all the available information.
        //Timetable timetable = initializeTimetable(school);
		Timetable timetable = new Timetable();
        timetable=addClassroomPreference(timetable, classroomPreference);
		timetable=addPeriodPreference(timetable, periodPreference);
		timetable=addRoom(timetable, rooms);
		timetable=addPeriod(timetable);
		timetable=addLecturers(timetable, lecturers);
		timetable=addCourse(timetable, courses);
		timetable=addSection(timetable, sections);
        // Initialize GA
        GeneticAlgorithm ga = new GeneticAlgorithm(100, 0.01, 0.9, 2, 5);
//        logger.info("GeneticAlgorithm ga = new GeneticAlgorithm(100, 0.01, 0.9, 2, 5);");
        // Initialize population
        //Population population = ga.initPopulation(timetable);
        Population population = ga.initPopulation(timetable);
//        logger.info(" Population population = ga.initPopulation(timetable);");
        // Evaluate population for first generation
        ga.evalPopulation(population, timetable);
//        logger.info("ga.evalPopulation(population, timetable);");
        // Keep track of current generation
        int generation = 2;
        long startTime = System.currentTimeMillis();
        
        //end limit in minutes which will be prompted from the user
        int endLimit = 10;
        int suggestionNo = 5;
        // Start evolution loop
//        logger.warn("loop "+ga.isTerminationConditionMet(startTime, endLimit));
//        logger.warn("loop "+ga.isTerminationConditionMet(population,suggestionNo));
        while (ga.isTerminationConditionMet(startTime, endLimit) == false
                && ga.isTerminationConditionMet(population,suggestionNo) == false) {
            // Print fitness
//        	logger.info("Possible Slot: " + generation + "\n \t->Best fitness: " + population.getFittest(0).getFitness());

            // Apply crossover
            //population = ga.crossoverPopulation(population);
            population = ga.crossoverPopulation(population,timetable);

            // Apply mutation
            //population = ga.mutatePopulation(population, timetable);
            population = ga.mutatePopulation(population, timetable);
            
            // Evaluate population for generation
            ga.evalPopulation(population, timetable);
            
            // Increment the current generation
            TimetableGA.percent=population.getFittest(0).getFitness()*100;
            generation++;
        }
        //The first solution that is generated
//        logger.warn("Out of the while");
        timetable.createslots(population.getFittest(0));
        TimetableGA.percent=100;
//        logger.info("*****");
//        logger.info("Solution found in " + generation + " generations");
//        logger.info("Final solution fitness: " + population.getFittest(0).getFitness());
        logger.info("Clashes: " + timetable.calcClashes());

        // Print slots
        Slot slots[] = timetable.getslots();
        int slotIndex = 1;
        ArrayList<SlotWrapper> slotWrapper=new ArrayList<>();
        for (Slot bestSlot : slots) {
            
        	slotWrapper.add(new SlotWrapper(bestSlot.getSectionId(),bestSlot.getRoomId(),
        			bestSlot.getPeriodId(),bestSlot.getCourseId(),bestSlot.getLecturerId()));
        	/*logger.info("############  Slot " + slotIndex + "   #############");
        	logger.info("Course: " + 
                    timetable.getCourse(bestSlot.getCourseId()).getCourseName());
        	logger.info("Section: " + 
                    timetable.getSection(bestSlot.getSectionId()).getSectionId());
        	logger.info("Slotroom: " + 
                    timetable.getRoom(bestSlot.getRoomId()).getRoomNumber());
        	logger.info("Lecturer: " + 
                    timetable.getLecturer(bestSlot.getLecturerId()).getLecturerName());
        	logger.info("Time: " + 
                    timetable.getPeriod(bestSlot.getPeriodId()).getPeriod());
        	logger.info("-----");*/
            slotIndex++;
        }
        
        //this is for slot suggestion
        timetable.createslots(population.getFittest(1));
        /*System.out.println("\n\t<<< THE SECOND OPTION AS A SUGGESTION >>>");
        slots = timetable.getslots();
        slotIndex = 1;
        for (Slot bestSlot : slots) {
            
        	logger.info("############  Slot " + slotIndex + "   #############");
        	logger.info("Course: " + 
                    timetable.getCourse(bestSlot.getCourseId()).getCourseName());
        	logger.info("Section: " + 
                    timetable.getSection(bestSlot.getSectionId()).getSectionId());
        	logger.info("Slotroom: " + 
                    timetable.getRoom(bestSlot.getRoomId()).getRoomNumber());
        	logger.info("Lecturer: " + 
                    timetable.getLecturer(bestSlot.getLecturerId()).getLecturerName());
        	logger.info("Time: " + 
                    timetable.getPeriod(bestSlot.getPeriodId()).getPeriod());
        	logger.info("-----");
            slotIndex++;
        }*/
        
        
        
        return slotWrapper;
    }

    /**
     * Creates a Timetable with all the necessary course information.
     * 
     * Normally you'd get this info from a database.
     * 
     * @return
     */
	private static Timetable addClassroomPreference(Timetable timetable,HashMap<Integer,Integer[]> classroomPreference) {
//		logger.info("addPeriodPreference "+classroomPreference.size());
		int preferenceNo=0;
		for(Integer sectionNo:classroomPreference.keySet()) {
//			logger.debug("in-loop-classpref");
			int[] classroomId=new int[classroomPreference.get(sectionNo).length];
			int counter=0;
			for(Integer value:classroomPreference.get(sectionNo)) {
				classroomId[counter++]=value;
			}
			timetable.addPreference(preferenceNo++, sectionNo,classroomId , 2);
		}
		return timetable;
	}
	private static Timetable addPeriodPreference(Timetable timetable,HashMap<Integer,Integer[]> periodPreference) {
//		logger.info("addPeriodPreference "+periodPreference.size());
		int preferenceNo=0;
		for(Integer sectionNo:periodPreference.keySet()) {
//			logger.debug("in-loop-pref");
			int[] classroomId=new int[periodPreference.get(sectionNo).length];
			int counter=0;
			for(Integer value:periodPreference.get(sectionNo)) {
				classroomId[counter++]=value;
			}
			timetable.addPreference(preferenceNo++, sectionNo,classroomId , 1);
		}
		return timetable;
	}
	private static Timetable addLecturers(Timetable timetable,Lecturer[] lecturers) {
//		logger.info("addLecturers");
		for(Lecturer lecturer:lecturers){
			timetable.addLecturer(lecturer.getLecturerId(), lecturer.getLecturerName(), lecturer.getMaximumEffort());
//			logger.debug(lecturer.toString());
//			logger.debug("in-loop-lecturers");
		}
		return timetable;
	}
	private static Timetable addCourse(Timetable timetable,Course[] courses) {
//		logger.info("addCourse");
		for(Course course:courses){
			timetable.addCourse(course.getCourseId(), course.getCourseCode(),
					course.getCourseName(),course.getLecturers());
//			logger.debug(course.toString());
//			logger.debug("in-loop-course");
		}
		return timetable;
	}
	private static Timetable addPeriod(Timetable timetable) {
//		logger.info("addPeriod");
		int count=1;
		for(Days day:Days.values()) {
			for(Sessions session:Sessions.values()) {
//				logger.debug("in-loop-addPeriod");
				timetable.addPeriod(count, day.toString()+" "+session.toString());
				count++;
//				logger.debug(count+" "+day.toString()+" "+session.toString());
//				logger.debug("in-loop-period");
			}
		}
		return timetable;
	}
	private static Timetable addRoom(Timetable timetable,Room[] rooms) {
//		logger.info("addRoom");
		for(Room room:rooms){
			timetable.addRoom(room.getRoomId(),room.getRoomNumber(), room.getRoomCapacity());
//			logger.debug(rooms.toString());
//			logger.debug("in-loop-room");
		}
			
		return timetable;
	}
	private static Timetable addSection(Timetable timetable,Section[] sections) {
//		logger.info("addSection");
		for(Section section:sections){
			timetable.addSection(section.getSectionId(), section.getSectionName(),section.getSectionSize(),section.getCourseIds());
//			logger.debug(section.toString());
//			logger.debug("in-loop-sections");
		}
		return timetable;
	}
}
