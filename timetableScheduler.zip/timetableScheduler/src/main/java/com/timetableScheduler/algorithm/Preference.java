/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

import java.util.HashMap;

/**
 *
 * @author Daniel
 */
public class Preference {
        private int preferenceId;
        private final HashMap<Integer, int[]> classroomPreference = new HashMap<>();;
        private final HashMap<Integer, int[]> periodPreference = new HashMap<>();
        private final HashMap<Integer, int[]> coursePriority = new HashMap<>();
        int preferenceType;    
        int preferring;

        public Preference(int preferenceId, Integer preferring, int[] preference, int preferenceType) {
            this.preferring = preferring;
            this.preferenceType = preferenceType;
            this.preferenceId = preferenceId;
            switch (preferenceType) {
                case 1:
                    this.periodPreference.put(preferring, preference);
                    periodPreference.keySet().forEach((i) -> {
//                        System.out.println("Period preference " + this.periodPreference.get(i)[0] + " , " + preferring);
                    }); break;
                case 2:
                    this.classroomPreference.put(preferring, preference);
                    classroomPreference.keySet().forEach((i) -> {
//                        System.out.println("Classroom preference " + this.classroomPreference.get(i)[0] + " , "+ this.classroomPreference.isEmpty() +" , " + preferring);
                    });
                    break;
                case 3:
                    this.coursePriority.put(preferring, preference);
                    coursePriority.keySet().forEach((i) -> {
//                        System.out.println("Course Priority " + this.coursePriority.get(i)[0] + " , "+ this.coursePriority.isEmpty() +" , " + preferring);
                    });
                    break;
                default:
                    break;
            }
        }
        public Preference(){
            

        }
        public int getPreferring(){
            return preferring;
        }
        
        public int[] getPeriodPreference(int key){
            //System.out.println("on preference the get returns" + periodPreference.get(key).length);
            return periodPreference.get(key);
            
        }
        
        public int[] getClassroomPreference(int key){
            //System.out.println("on preference the get returns" + classroomPreference.get(key).length);
            return classroomPreference.get(key);
        }
        public int[] getCoursePreference(int key){
            
            return coursePriority.get(key);
        }
        public int getPreferenceId() {
            return preferenceId;
        }

        public void setPreferenceId(int preferenceId) {
            this.preferenceId = preferenceId;
        }
        public int getPreferenceType(){
            return preferenceType;
        }

        public void setClassroomPreferences(Integer sectionId, int[] classroomsId) {
            this.classroomPreference.put(sectionId, classroomsId);
        }
        public void setPeriodPreferences(Integer lecturerId, int[] periodsId) {
            this.periodPreference.put(lecturerId, periodsId);
        }

}
