/*
 * Timetable Scheduler done by AAiT Students 
 * 2011 E.C
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */

import java.util.HashMap;


public class Timetable {
	private final HashMap<Integer, Room> rooms;
	private final HashMap<Integer, Lecturer> Lecturers;
	private final HashMap<Integer, Course> courses;
	private final HashMap<Integer, Section> sections;
	private final HashMap<Integer, Period> periods;
        private final HashMap<Integer, Preference> preferences;
	private Slot slots[];
	private int numslots = 0;

	//Initialize new Timetable within the objects attribute values.
	public Timetable() {
		this.rooms = new HashMap<Integer, Room>();
		this.Lecturers = new HashMap<Integer, Lecturer>();
		this.courses = new HashMap<Integer, Course>();
		this.sections = new HashMap<Integer, Section>();
		this.periods = new HashMap<Integer, Period>();
                this.preferences = new HashMap<Integer, Preference>();
	}

	//to clone the ready made timetable
	public Timetable(Timetable cloneable) {
		this.rooms = cloneable.getRooms();
		this.Lecturers = cloneable.getLecturers();
		this.courses = cloneable.getCourses();
		this.sections = cloneable.getSections();
		this.periods = cloneable.getPeriods();
                this.preferences = cloneable.getPreferences();
	}

	private HashMap<Integer, Section> getSections() {
		return this.sections;
	}

	private HashMap<Integer, Period> getPeriods() {
		return this.periods;
	}

	private HashMap<Integer, Course> getCourses() {
		return this.courses;
	}

	private HashMap<Integer, Lecturer> getLecturers() {
		return this.Lecturers;
	}

	
	public void addRoom(int roomId, String roomName, int capacity) {
		this.rooms.put(roomId, new Room(roomId, roomName, capacity));
	}

	
	public void addLecturer(int LecturerId, String LecturerName, int maxEffort) {
		this.Lecturers.put(LecturerId, new Lecturer(LecturerId, LecturerName, maxEffort));
	}

	
	public void addCourse(int courseId, String courseCode, String course, int LecturerIds[]) {
		this.courses.put(courseId, new Course(courseId, courseCode, course, LecturerIds));
	}

	
	public void addSection(int sectionId, String sectionName, int sectionSize, int courseIds[]) {
		this.sections.put(sectionId, new Section(sectionId,sectionName, sectionSize, courseIds));
		this.numslots = 0;
	}

	
	public void addPeriod(int periodId, String period) {
		this.periods.put(periodId, new Period(periodId, period));
	}
        
        public void addPreference(int preferenceId, Integer preferee, int [] preference, int type){
            this.preferences.put(preferenceId, new Preference(preferenceId, preferee, preference, type));
        }

	public void createslots(Individual individual) {
		// Init slots
		Slot slots[] = new Slot[this.getNumslots()];

		// Get individual's chromosome
		int chromosome[] = individual.getChromosome();
		int chromosomePos = 0;
		int slotIndex = 0;

		for (Section section : this.getSectionsAsArray()) {
			int courseIds[] = section.getCourseIds();
			for (int courseId : courseIds) {
				slots[slotIndex] = new Slot(slotIndex, section.getSectionId(), courseId);

				// Add room
                                //System.out.println("CHR POS:  " + chromosomePos+ "  ,  roomId:" +chromosome[chromosomePos] );
				slots[slotIndex].setRoomId(chromosome[chromosomePos]);
				chromosomePos++;

                                // Add period
				slots[slotIndex].addPeriod(chromosome[chromosomePos]);
				chromosomePos++;
                                
				// Add Lecturer
				slots[slotIndex].addLecturer(chromosome[chromosomePos]);
				chromosomePos++;

				slotIndex++;
			}
		}

		this.slots = slots;
	}

        public void createslots(Individual individual, int numberOfSlots) {
		// Init slots
		Slot slots[] = new Slot[numberOfSlots];

		// Get individual's chromosome
		int chromosome[] = individual.getChromosome();
		int chromosomePos = 0;
		int slotIndex = 0;

		for (int section = 0; section<numberOfSlots; section++) {
                    slots[section] = new Slot(section, section,slotIndex );
                    slots[section].addPeriod(chromosome[chromosomePos]);
                    chromosomePos++;
                    slots[section].setRoomId(chromosome[chromosomePos]);
                    chromosomePos++;
                    slots[section].addLecturer(chromosome[chromosomePos]);
                    chromosomePos++;
                }    
			
		

		this.slots = slots;
	}
	public Room getRoom(int roomId) {
		if (!this.rooms.containsKey(roomId)) {
			System.out.println("Rooms doesn't contain key " + roomId);
		}
		return (Room) this.rooms.get(roomId);
	}

	public HashMap<Integer, Room> getRooms() {
		return this.rooms;
	}

	public Room getRandomRoom() {
		Object[] roomsArray = this.rooms.values().toArray();
//                for(Object r:roomsArray){
//                    Room room = (Room)r;
//                    System.out.println("each room are"+room.getRoomId());
//                }
		Room room = (Room) roomsArray[(int) (roomsArray.length * Math.random())];
		return room;
	}

	public Lecturer getLecturer(int LecturerId) {
		return (Lecturer) this.Lecturers.get(LecturerId);
	}

	public Course getCourse(int courseId) {
		return (Course) this.courses.get(courseId);
	}

	public int[] getSectionCourses(int sectionId) {
		Section section = (Section) this.sections.get(sectionId);
		return section.getCourseIds();
	}


	public Section getSection(int sectionId) {
		return (Section) this.sections.get(sectionId);
	}

	public Section[] getSectionsAsArray() {
		return (Section[]) this.sections.values().toArray(new Section[this.sections.size()]);
	}
        
        public Lecturer[] getLecturersAsArray(){
                return (Lecturer[]) this.Lecturers.values().toArray(new Lecturer[this.Lecturers.size()]);
        }
	
	public Period getPeriod(int periodId) {
		return (Period) this.periods.get(periodId);
	}

	/**
	 * Get random periodId
	 * 
	 * @return period
	 */
	public Period getRandomPeriod() {
		Object[] periodArray = this.periods.values().toArray();
		Period period = (Period) periodArray[(int) (periodArray.length * Math.random())];
		return period;
	}

	/**
	 * Get slots
	 * 
	 * @return slots
	 */
	public Slot[] getslots() {
		return this.slots;
	}
        
        public HashMap<Integer, Preference> getPreferences(){
            return this.preferences;
        }
        public Preference getPreference(int preferenceId){
            System.out.println("on timetable the get preference " + this.getPreferences().get(preferenceId) );
            return this.getPreferences().get(preferenceId);
        }
	//To get the number of slots that need scheduling
	 
	public int getNumslots() {
		if (this.numslots > 0) {
			return this.numslots;
		}

		int numslots = 0;
		Section sections[] = (Section[]) this.sections.values().toArray(new Section[this.sections.size()]);
		for (Section section : sections) {
			numslots += section.getCourseIds().length;
		}
		this.numslots = numslots;

		return this.numslots;
	}
        
	/**
	 * Calculate the number of clashes between slots generated by a
	 * chromosome.
	 * 
	 * The most important method in this class; look at a candidate timetable
	 * and figure out how many constraints are violated.
	 * 
	 * Running this method requires that createslots has been run first (in
	 * order to populate this.slots). The return value of this method is
	 * simply the number of constraint violations (conflicting Lecturers,
	 * periods, or rooms), and that return value is used by the
	 * GeneticAlgorithm.calcFitness method.
	 * 
	 * There's nothing too difficult here either -- loop through this.slots,
	 * and check constraints against the rest of the this.slots.
	 * 
	 * The two inner `for` loops can be combined here as an optimization, but
	 * kept separate for clarity. For small values of this.slots.length it
	 * doesn't make a difference, but for larger values it certainly does.
	 * 
	 * @return numClashes
	 */
	public int calcClashes() {
		int clashes = 0;

		for (Slot slotA : this.slots) {
			// Check room capacity
                        //System.out.println("errors on room"+slotA.getRoomId());
//                        if(slotA.getRoomId()==40){
//                            for(Slot slt: this.slots){
//                                System.out.println(slotA.getSlotId() +" the betrayer room:"+slt.getRoomId()+" , lect:" +slt.getLecturerId()+" , per:" +slt.getPeriodId());
//                            }
//                            
//                        }
			int roomCapacity = this.getRoom(slotA.getRoomId()).getRoomCapacity();
			int sectionSize = this.getSection(slotA.getSectionId()).getSectionSize();
			
			if (roomCapacity < sectionSize) {
				clashes++;
			}

			// Check if room is taken
			for (Slot slotB : this.slots) {
				if (slotA.getRoomId() == slotB.getRoomId() && slotA.getPeriodId() == slotB.getPeriodId()
						&& slotA.getSlotId() != slotB.getSlotId()) {
					clashes++;
					break;
				}
			}

			// Check if Lecturer is available
			for (Slot slotB : this.slots) {
				if (slotA.getLecturerId() == slotB.getLecturerId() && slotA.getPeriodId() == slotB.getPeriodId()
						&& slotA.getSlotId() != slotB.getSlotId()) {
					clashes++;
					break;
				}
			}
		}

		return clashes;
	}
}