/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */

public class Slot {
    private final int slotId;
    private final int sectionId;
    private final int courseId;
    private int LecturerId;
    private int periodId;
    private int roomId;
    
    /**
     * Initialize new Slot
     * 
     * @param slotId
     * @param sectionId
     * @param courseId
     */
    public Slot(int slotId, int sectionId, int courseId){
        this.slotId = slotId;
        this.courseId = courseId;
        this.sectionId = sectionId;
    }
    
    /**
     * Add Lecturer to slot
     * 
     * @param LecturerId
     */
    public void addLecturer(int LecturerId){
        this.LecturerId= LecturerId;
    }
    
    /**
     * Add period to slot
     * 
     * @param periodId
     */
    public void addPeriod(int periodId){
        this.periodId = periodId;
    }    
    
    /**
     * Add room to slot
     * 
     * @param roomId
     */
    public void setRoomId(int roomId){
        this.roomId = roomId;
    }
    
    /**
     * Get slotId
     * 
     * @return slotId
     */
    public int getSlotId(){
        return this.slotId;
    }
    
    /**
     * Get sectionId
     * 
     * @return sectionId
     */
    public int getSectionId(){
        return this.sectionId;
    }
    
    /**
     * Get courseId
     * 
     * @return courseId
     */
    public int getCourseId(){
        return this.courseId;
    }
    
    /**
     * Get LecturerId
     * 
     * @return LecturerId
     */
    public int getLecturerId(){
        return this.LecturerId;
    }
    
    /**
     * Get periodId
     * 
     * @return periodId
     */
    public int getPeriodId(){
        return this.periodId;
    }
    
    /**
     * Get roomId
     * 
     * @return roomId
     */
    public int getRoomId(){
        return this.roomId;
    }
}

