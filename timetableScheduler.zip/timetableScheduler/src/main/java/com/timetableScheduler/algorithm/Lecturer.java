/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */

/**
 * Simple Lecturer abstraction.
 */
public class Lecturer {
    private final int LecturerId;
    private final String lecturerName;
    private final int maximumEffort;
    /**
     * Initalize new Lecturer
     * 
     * @param LecturerIdThe Idfor this Lecturer
     * @param lecturerName The name of this Lecturer
     */
    public Lecturer(int LecturerId, String lecturerName, int maxEffort){
        this.LecturerId= LecturerId;
        this.lecturerName = lecturerName;
        maximumEffort = maxEffort;
    }
    
    /**
     * Get LecturerId
     * 
     * @return LecturerId
     */
    public int getLecturerId(){
        return this.LecturerId;
    }
    
    /**
     * Get Lecturer's name
     * 
     * @return lecturerName
     */
    public String getLecturerName(){
        return this.lecturerName;
    }
    
    public int getMaximumEffort(){
        return this.maximumEffort;
    }
}
