/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.HashMap;

/**
 *
 * @author Daniel
 */


public class GeneticAlgorithm {

	private int populationSize;
	private double mutationRate;
	private double crossoverRate;
	private int elitismCount;
	protected int tournamentSize;

	public GeneticAlgorithm(int populationSize, double mutationRate, double crossoverRate, int elitismCount,
			int tournamentSize) {

		this.populationSize = populationSize;
		this.mutationRate = mutationRate;
		this.crossoverRate = crossoverRate;
		this.elitismCount = elitismCount;
		this.tournamentSize = tournamentSize;
	}

	//Initialize population
	//ChromosomeLength is the length of the individuals chromosome
	public Population initPopulation(Timetable timetable) {
		// Initialize population
		Population population = new Population(this.populationSize, timetable);
		return population;
	}
        
        //init population for the run type of the number of lectures limit
        public Population initPopulation(Timetable timetable, int considerLectureLimit) {
		// Initialize population
		Population population = new Population(this.populationSize, timetable, considerLectureLimit );
		return population;
	}
                
        //to check the termination condition
	public boolean isTerminationConditionMet(long startTime, int stopIn) {
                long currentTime = System.currentTimeMillis();
                long operationMillis = stopIn * 60000;
                return currentTime-startTime >= operationMillis;
                
	}

	// Check if population has met termination condition
	public boolean isTerminationConditionMet(Population population, int suggestionNo) {
                boolean achieved = false;
		for(int i = 0; i<= suggestionNo; i++){
                    if(!(population.getFittest(i).getFitness() == 1.0)){
                        achieved = false;
                        break;
                    }
                    else{
                        achieved = true;
                    }
                }
                return achieved;
	}

	//Calculate individual's fitness value
	 
	public double calcFitness(Individual individual, Timetable timetable) {

		// Create new timetable object to use -- cloned from an existing timetable
		Timetable threadTimetable = new Timetable(timetable);
		threadTimetable.createslots(individual);
                
		// Calculate fitness
		int clashes = threadTimetable.calcClashes();
		double fitness = 1 / (double) (clashes + 1);

		individual.setFitness(fitness);

		return fitness;
	}

	//
	public void evalPopulation(Population population, Timetable timetable) {
		double populationFitness = 0;

		// Loop over population evaluating individuals and summing population
		// fitness
		for (Individual individual : population.getIndividuals()) {
			populationFitness += this.calcFitness(individual, timetable);
		}

		population.setPopulationFitness(populationFitness);
	}

	/**
	 * Selects parent for crossover using tournament selection
	 * 
	 * Tournament selection works by choosing N random individuals, and then
	 * choosing the best of those.
	 * 
	 * @param population
	 * @return The individual selected as a parent
	 */
	public Individual selectParent(Population population) {
		// Create tournament
		Population tournament = new Population(this.tournamentSize);

		// Add random individuals to the tournament
		population.shuffle();
		for (int i = 0; i < this.tournamentSize; i++) {
			Individual tournamentIndividual = population.getIndividual(i);
			tournament.setIndividual(i, tournamentIndividual);
		}

		// Return the best
		return tournament.getFittest(0);
	}


	/**
     * Apply mutation to population
     * 
     * @param population
     * @param timetable
     * @return The mutated population
     */
	public Population mutatePopulation(Population population, Timetable timetable, int a ) {
		// Initialize new population
		Population newPopulation = new Population(this.populationSize);

		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual individual = population.getFittest(populationIndex);

			// Create random individual to swap genes with
			Individual randomIndividual = new Individual(timetable);

			// Loop over individual's genes
			for (int geneIndex = 0; geneIndex < individual.getChromosomeLength(); geneIndex++) {
				// Skip mutation if this is an elite individual
				if (populationIndex > this.elitismCount) {
					// Does this gene need mutation?
					if (this.mutationRate > Math.random()) {
						// Swap for new gene
						individual.setGene(geneIndex, randomIndividual.getGene(geneIndex));
					}
				}
			}

			// Add individual to population
			newPopulation.setIndividual(populationIndex, individual);
		}

		// Return mutated population
		return newPopulation;
	}
        //mutation that considers the preference of section and 
        public Population mutatePopulation(Population population, Timetable timetable) {
		// Initialize new population
		Population newPopulation = new Population(this.populationSize);
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePreference = new HashMap<>();
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" GA jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnGA " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnGA " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePreference.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(0));
                            break;
                        default:
                            break;
                    }
                });
                
		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual individual = population.getFittest(populationIndex);

			// Create random individual to swap genes with
			Individual randomIndividual = new Individual(timetable);

                        //an array that contains the slot position on the chromosome
                        int[] indices = new int[individual.getChromosomeLength()/3];
                        int value = 0;;
                        for(int i = 0; i<indices.length;i++){
                            indices[i] = value + 3;
                            value = indices[i];
                        }
			// Loop over individual's genes
			for (int geneIndex = 0; geneIndex < individual.getChromosomeLength(); geneIndex++) {
				
                                //checking whether the slot is present in preference list
                                boolean atRoomOffset = false;
                                int useful=0;
                                for(int in: indices){
                                    if(in == geneIndex){
                                        atRoomOffset = true;
                                        break;
                                    }
                                    useful++;
                                }
                                if (atRoomOffset){
                                    
                                    timetable.createslots(individual);
                                    //System.out.println("daniel: " + timetable.getNumslots());
                                    Slot[] slot = timetable.getslots();
                                    //System.out.println("ante " + slot.length + " , " + slot[useful].getSectionId());
                                    boolean returned = false;
                                    if(classroomPreference.containsKey(slot[useful].getSectionId())){
                                        //System.out.println("crossover checked222");
                                        int[] rooms =  classroomPreference.get(slot[useful].getSectionId());
                                        for(int room: rooms){
                                            if(room == slot[useful].getRoomId()){
                                                returned = true;
                                                geneIndex -= 3;
                                                break;
                                            }
                                        }                                       
                                        //System.out.println("crossover checked");
                                    } 
                                    if(periodPreference.containsKey(slot[useful].getLecturerId()) && (!returned)){
                                        int[] periods = periodPreference.get(slot[useful].getLecturerId());
                                        //System.out.println("crossover checked3 " + periodPreference.get(1)[0]);
                                        for(int period: periods){
                                            if(period == slot[useful].getPeriodId()){
                                                geneIndex -= 3;
                                                break;
                                            }
                                        } 
                                    }
                                            
                                }
                                // Skip mutation if this is an elite individual
				if (populationIndex > this.elitismCount) {
					// Does this gene need mutation?
					if (this.mutationRate > Math.random()) {
						// Swap for new gene
						individual.setGene(geneIndex, randomIndividual.getGene(geneIndex));
					}
				}
			}

			// Add individual to population
			newPopulation.setIndividual(populationIndex, individual);
		}

		// Return mutated population
		return newPopulation;
	}

        public Population mutatePopulationWithLectureCount(Population population, Timetable timetable) {
		// Initialize new population
		Population newPopulation = new Population(this.populationSize);
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePreference = new HashMap<>();
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" GA jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnGA " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnGA " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePreference.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(0));
                            break;
                        default:
                            break;
                    }
                });
                
                int[] indices = new int[population.getFittest(0).getChromosomeLength()/3];
                int value1 = 0;
                for(int i = 0; i<indices.length;i++){
                    indices[i] = value1 + 3;
                    value1 = indices[i];
                }
                int[] indices2 = new int[population.getFittest(0).getChromosomeLength()/3];
                int value2 = 0;
                for(int i=0; i<indices2.length;i++){
                    if(i ==0){
                        indices2[i] = 2;
                        value2 = indices2[i];
                        continue;
                    }
                    indices2[i] = value2 + 3;
                    value2 = indices2[i];
                    //System.out.println("indices2" + indices2[i]);
                }
                
		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual individual = population.getFittest(populationIndex);
                        HashMap<Integer, Integer> numberOfLecture = new HashMap<>();
			// Create random individual to swap genes with
			Individual randomIndividual = new Individual(timetable, 1);

			// Loop over individual's genes
			for (int geneIndex = 0; geneIndex < individual.getChromosomeLength(); geneIndex++) {
				
                                //checking whether the slot is present in preference list
                                boolean atRoomOffset = false;
                                int useful=0;
                                for(int in: indices){
                                    if(in == geneIndex){
                                        atRoomOffset = true;
                                        break;
                                    }
                                    useful++;
                                }
                                boolean atLecturerOffset = false;
                                int useful2=0;
                                for(int in2: indices2){
                                    if(in2 == geneIndex){
                                        atLecturerOffset = true;
                                        break;
                                    }
                                    useful2++;
                                }
                                if (atRoomOffset){
                                    
                                    timetable.createslots(individual);
                                    //System.out.println("daniel: " + timetable.getNumslots());
                                    Slot[] slot = timetable.getslots();
                                    //System.out.println("ante " + slot.length + " , " + slot[useful].getSectionId());
                                    boolean returned = false;
                                    if(classroomPreference.containsKey(slot[useful].getSectionId())){
                                        //System.out.println("crossover checked222");
                                        int[] rooms =  classroomPreference.get(slot[useful].getSectionId());
                                        for(int room: rooms){
                                            if(room == slot[useful].getRoomId()){
                                                returned = true;
                                                geneIndex -= 3;
                                                break;
                                            }
                                        }                                       
                                        //System.out.println("crossover checked");
                                    } 
                                    if(periodPreference.containsKey(slot[useful].getLecturerId()) && (!returned)){
                                        int[] periods = periodPreference.get(slot[useful].getLecturerId());
                                        //System.out.println("crossover checked3 " + periodPreference.get(1)[0]);
                                        for(int period: periods){
                                            if(period == slot[useful].getPeriodId()){
                                                geneIndex -= 3;
                                                break;
                                            }
                                        } 
                                    }
                                            
                                }
                                boolean checked = false;
                                //checking whether the to be assigned lecturer doesn't attain his/her limit
                                if(atLecturerOffset){
                                    //System.out.println("i am here "+ geneIndex);
                                    // Does this gene need mutation?
                                        //System.out.println("I am here too " + geneIndex);
					int lecturerToBeAssigned = randomIndividual.getGene(geneIndex) ;
                                        if(!numberOfLecture.containsKey(lecturerToBeAssigned)){
                                            numberOfLecture.put(lecturerToBeAssigned, 0);
                                        }
                                        int maxEff = timetable.getLecturer(lecturerToBeAssigned).getMaximumEffort();
                                        if(numberOfLecture.get(lecturerToBeAssigned)< maxEff){
                                            //System.out.println("true "+ lecturerToBeAssigned);
                                            numberOfLecture.replace(lecturerToBeAssigned, numberOfLecture.get(lecturerToBeAssigned)+1);
                                            individual.setGene(geneIndex, lecturerToBeAssigned);
                                            checked = true;
                                        }
                                        
                                        else if(numberOfLecture.get(lecturerToBeAssigned)> maxEff){
                                            for (Section section : timetable.getSectionsAsArray()) {
                                                int slotIndex = (geneIndex + 1)/3;
                                                int iter = 0;
                                                for (int courseId : section.getCourseIds()) {
                                                    iter++;
                                                    
                                                    if(iter== slotIndex){
                                                        //System.out.println("iter " + iter + "course Id " + courseId);
                                                        Course course = timetable.getCourse(courseId);
                                                        lecturerToBeAssigned = 0 ;
                                                        int exit = 0;
                                                        while(exit==0){
                                                            int[] lectList = course.LecturerIds;
                                                            for(int index =0;index<lectList.length;index++){
                                                                if(!numberOfLecture.containsKey(lectList[index])){
                                                                    numberOfLecture.put(lectList[index], 0);
                                                                }
                                                                maxEff = timetable.getLecturer(lectList[index]).getMaximumEffort();
                                                                if(numberOfLecture.get(lectList[index]) < maxEff){
                                                                    numberOfLecture.replace(lectList[index], numberOfLecture.get(lectList[index])+1);
                                                                    lecturerToBeAssigned = lectList[index];
                                                                    exit = 1;
                                                                    checked = true;
                                                                    //System.out.println("lect on crossover " + lecturerToBeAssigned +" "+geneIndex);
                                                                    break;
                                                                }
                                                                if(index == lectList.length-1){
                                                                    exit = 1;
                                                                }
                                                            }
                                                        }
                                                        if(!numberOfLecture.containsKey(lecturerToBeAssigned)){
                                                            numberOfLecture.put(lecturerToBeAssigned, 0);
                                                        }
                                                        if(lecturerToBeAssigned == 0){
                                                            lecturerToBeAssigned = timetable.getLecturersAsArray().length;
                                                            numberOfLecture.replace(lecturerToBeAssigned, numberOfLecture.get(lecturerToBeAssigned)+1);
                                                            //System.out.println("tba on crossover" + geneIndex);
                                                            checked = true;
                                                        }
                                                        individual.setGene(geneIndex, lecturerToBeAssigned);
                                                    }
                                                    if(checked){
                                                        break;
                                                    }
                                                }
                                                if(checked){
                                                    break;
                                                }
                                            }
                                        }
                                    
                                    
                                }
                                if(checked){
                                    continue;
                                }
                                          
                                // Skip mutation if this is an elite individual
				if (populationIndex > this.elitismCount) {
					// Does this gene need mutation?
					if (this.mutationRate > Math.random()) {
						// Swap for new gene
						individual.setGene(geneIndex, randomIndividual.getGene(geneIndex));
					}
				}
			}

			// Add individual to population
			newPopulation.setIndividual(populationIndex, individual);
		}

		// Return mutated population
		return newPopulation;
	}

        //Apply crossover to population
        public Population crossoverPopulation(Population population) {
		// Create new population
		Population newPopulation = new Population(population.size());

		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual parent1 = population.getFittest(populationIndex);

			// Apply crossover to this individual?
			if (this.crossoverRate > Math.random() && populationIndex >= this.elitismCount) {
				// Initialize offspring
				Individual offspring = new Individual(parent1.getChromosomeLength());
				
				// Find second parent
				Individual parent2 = selectParent(population);

				// Loop over genome
				for (int geneIndex = 0; geneIndex < parent1.getChromosomeLength(); geneIndex++) {
					// Use half of parent1's genes and half of parent2's genes
					if (0.5 > Math.random()) {
						offspring.setGene(geneIndex, parent1.getGene(geneIndex));
					} else {
						offspring.setGene(geneIndex, parent2.getGene(geneIndex));
					}
				}

				// Add offspring to new population
				newPopulation.setIndividual(populationIndex, offspring);
			} else {
				// Add individual to new population without applying crossover
				newPopulation.setIndividual(populationIndex, parent1);
			}
		}

		return newPopulation;
	}
        
        //Apply crossover to population
        public Population crossoverPopulation(Population population, Timetable timetable) {
		// Create new population
		Population newPopulation = new Population(population.size());
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePriority = new HashMap<>();
                
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" GA jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnGA " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnGA " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePriority.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(0));
                            break;
                        default:
                            break;
                    }
                });
                
		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual parent1 = population.getFittest(populationIndex);
                        //System.out.println("periodPrefOnCO " + periodPreference.get(2)[0]);
                        //System.out.println("ClassroomPrefOnCO " + classroomPreference.keySet());
			// Apply crossover to this individual?
			if (this.crossoverRate > Math.random() && populationIndex >= this.elitismCount) {
				// Initialize offspring
				Individual offspring = new Individual(parent1.getChromosomeLength());
				   
				// Find second parent
				Individual parent2 = selectParent(population);
                                
                                //an array that contains the slot position on the chromosome
                                int[] indices = new int[parent1.getChromosomeLength()/3];
                                int value = 0;
                                for(int i = 0; i<indices.length;i++){
                                    indices[i] = value + 3;
                                    value = indices[i];
                                }
                                
                                
				// Loop over genome
				for (int geneIndex = 0; geneIndex < parent1.getChromosomeLength(); geneIndex++) {
                                        //System.out.println("but here " + geneIndex );
                                        boolean atRoomOffset = false;
                                        int useful=0;
                                        for(int in: indices){
                                            if(in == geneIndex){
                                                atRoomOffset = true;
                                                break;
                                            }
                                            useful++;
                                        }
                                        if (atRoomOffset){
                                            //System.out.println("crossover checked1");
                                            Individual offspringTemp  = new Individual(parent1.getChromosomeLength());
                                            for (Section section : timetable.getSectionsAsArray()) {
                                                // Loop through courses
                                                int chromInd = 0;
                                                for (int courseId : section.getCourseIds()) {
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        //System.out.println("wow"+offspring.getGene(chromInd-1));
                                                }
                                            }
                                            timetable.createslots(offspringTemp);
                                            //System.out.println("daniel: " + timetable.getNumslots());
                                            Slot[] slot = timetable.getslots();
                                            //System.out.println("ante " + slot.length + " , " + slot[useful].getSectionId());
                                            boolean returned = false;
                                            if(classroomPreference.containsKey(slot[useful].getSectionId())){
                                                //System.out.println("crossover checked222");
                                                int[] rooms =  classroomPreference.get(slot[useful].getSectionId());
                                                for(int room: rooms){
                                                    if(room == slot[useful].getRoomId()){
                                                        returned = true;
                                                        geneIndex -= 3;
                                                        break;
                                                    }
                                                }                                       
                                                //System.out.println("crossover checked");
                                            } 
                                            if(periodPreference.containsKey(slot[useful].getLecturerId()) && (!returned)){
                                                int[] periods = periodPreference.get(slot[useful].getLecturerId());
                                                //System.out.println("crossover checked3 " + periodPreference.get(1)[0]);
                                                for(int period: periods){
                                                    if(period == slot[useful].getPeriodId()){
                                                        geneIndex -= 3;
                                                        break;
                                                    }
                                                } 
                                            }
                                            returned = false;
                                            
                                        }
                                        
                                        
                                        
                                        // Use half of parent1's genes and half of parent2's genes
                                        
                                        if (0.5 > Math.random()) {
						offspring.setGene(geneIndex, parent1.getGene(geneIndex));
                                                //System.out.println("gi " + geneIndex + " , " + parent1.getGene(geneIndex));
					} else {
						offspring.setGene(geneIndex, parent2.getGene(geneIndex));
                                                //System.out.println("gene index: " + geneIndex + ", gene: " + offspring.getGene(geneIndex));
					}
				}

				// Add offspring to new population
				newPopulation.setIndividual(populationIndex, offspring);
			}
                        else {
				// Add individual to new population without applying crossover
				newPopulation.setIndividual(populationIndex, parent1);
			}
		}

		return newPopulation;
	}

        public Population crossoverPopulationWithLectureCount(Population population, Timetable timetable) {
		// Create new population
		Population newPopulation = new Population(population.size());
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePriority = new HashMap<>();
                
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" GA jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnGA " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnGA " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePriority.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(0));
                            break;
                        default:
                            break;
                    }
                });
                
		// Loop over current population by fitness
		for (int populationIndex = 0; populationIndex < population.size(); populationIndex++) {
			Individual parent1 = population.getFittest(populationIndex);
                        HashMap<Integer, Integer> numberOfLecture = new HashMap<>();
			// Apply crossover to this individual?
			if (this.crossoverRate > Math.random() && populationIndex >= this.elitismCount) {
				// Initialize offspring
				Individual offspring = new Individual(timetable);
                                
				// Find second parent
				Individual parent2 = selectParent(population);
                                
                                //an array that contains the slot position on the chromosome
                                int[] indices = new int[parent1.getChromosomeLength()/3];
                                int value = 0;
                                for(int i = 0; i<indices.length;i++){
                                    indices[i] = value + 3;
                                    value = indices[i];
                                }
                                int[] indices2 = new int[parent1.getChromosomeLength()/3];
                                int value2 = 0;
                                for(int i=0; i<indices2.length;i++){
                                    if(i ==0){
                                        indices2[i] = 2;
                                        value2 = indices2[i];
                                        continue;
                                    }
                                    indices2[i] = value2 + 3;
                                    value2 = indices2[i];
                                    //System.out.println("indices2" + indices2[i]);
                                }
                                
				// Loop over genome
				for (int geneIndex = 0; geneIndex < parent1.getChromosomeLength(); geneIndex++) {
                                        //System.out.println("but here " + geneIndex );
                                        boolean atRoomOffset = false;
                                        int useful=0;
                                        for(int in: indices){
                                            if(in == geneIndex){
                                                atRoomOffset = true;
                                                break;
                                            }
                                            useful++;
                                        }
                                        
                                        boolean atLecturerOffset = false;
                                        int useful2=0;
                                        for(int in2: indices2){
                                            if(in2 == geneIndex){
                                                atLecturerOffset = true;
                                                break;
                                            }
                                            useful2++;
                                        }
                                        boolean checked = false;
                                        if(atLecturerOffset){
                                            //System.out.println("Gene Index: "+geneIndex);
                                                //System.out.println("parent1 " + parent1.getChromosomeLength() + " parent2 "+ parent2.getChromosomeLength());
                                                //System.out.println("offset of " + parent1.getGene(119));
                                                int lecturerToBeAssigned1 = parent1.getGene(geneIndex);
                                                //System.out.println("offset of " + parent2.getGene(119));
                                                int lecturerToBeAssigned2 = parent2.getGene(geneIndex);

                                                if(!numberOfLecture.containsKey(lecturerToBeAssigned1)){
                                                    numberOfLecture.put(lecturerToBeAssigned1, 0);
                                                }
                                                if(!numberOfLecture.containsKey(lecturerToBeAssigned2)){
                                                    numberOfLecture.put(lecturerToBeAssigned2, 0);
                                                }
                                                int maxEff1 = timetable.getLecturer(lecturerToBeAssigned1).getMaximumEffort();
                                                int maxEff2 = timetable.getLecturer(lecturerToBeAssigned2).getMaximumEffort();
                                                
                                                if((numberOfLecture.get(lecturerToBeAssigned1) < maxEff1)||(numberOfLecture.get(lecturerToBeAssigned2)< maxEff2)) {
                                                    if((numberOfLecture.get(lecturerToBeAssigned1) < maxEff1)&&(numberOfLecture.get(lecturerToBeAssigned2)< maxEff2)){
                                                        // Use half of parent1's genes and half of parent2's genes
                                                        if (0.5 > Math.random()) {
                                                                offspring.setGene(geneIndex, lecturerToBeAssigned1);
                                                        } else {
                                                                offspring.setGene(geneIndex, lecturerToBeAssigned2);
                                                        }
                                                    }
                                                    else if(numberOfLecture.get(lecturerToBeAssigned1) < maxEff1){
                                                        numberOfLecture.replace(lecturerToBeAssigned1, numberOfLecture.get(lecturerToBeAssigned1) + 1);
                                                        offspring.setGene(geneIndex, lecturerToBeAssigned1);
                                                    }
                                                    else if(numberOfLecture.get(lecturerToBeAssigned2)< maxEff2){
                                                        numberOfLecture.replace(lecturerToBeAssigned2, numberOfLecture.get(lecturerToBeAssigned2) + 1);
                                                        offspring.setGene(geneIndex, lecturerToBeAssigned2);
                                                    }
                                                    
                                                    //System.out.println("i think it works " + geneIndex);
                                                    checked = true;
                                                }
                                                else if((numberOfLecture.get(lecturerToBeAssigned1) >= maxEff1)&&(numberOfLecture.get(lecturerToBeAssigned2) >= maxEff2)){
                                                   //System.out.println("i think here works too " + geneIndex + "," +lecturerToBeAssigned1 + " : "+maxEff1 + " , "+ lecturerToBeAssigned2 + " : "+maxEff2 + " but "+ numberOfLecture.get(lecturerToBeAssigned2)  );
                                                    
                                                    for (Section section : timetable.getSectionsAsArray()) {
                                                        //System.out.println("aldeferem");
                                                        int slotIndex = (geneIndex + 1)/3;
                                                        int iter = 0;
                                                        for (int courseId : section.getCourseIds()) {
                                                            //System.out.println("aldeferem1");
                                                            iter += 1;
                                                            if(iter == slotIndex){
                                                                //System.out.println("aldeferem2 " + iter);
                                                                
                                                                Course course = timetable.getCourse(courseId);
                                                                int lecturerToBeAssigned =0;
                                                                int exit = 0;
                                                                while(exit==0){
                                                                    //System.out.println("in the while loop " + lecturerToBeAssigned);
                                                                    int[] lectList = course.LecturerIds;
                                                                    for(int index =0;index<lectList.length;index++){
                                                                        if(!numberOfLecture.containsKey(lectList[index])){
                                                                            numberOfLecture.put(lectList[index], 0);
                                                                        }
                                                                        int maxEff = timetable.getLecturer(lectList[index]).getMaximumEffort();
                                                                        if(numberOfLecture.get(lectList[index]) < maxEff){
                                                                            numberOfLecture.replace(lectList[index], numberOfLecture.get(lectList[index])+1);
                                                                            lecturerToBeAssigned = lectList[index];
                                                                            checked = true;
                                                                            exit = 1;
                                                                            break;
                                                                        }
                                                                        if(index == lectList.length-1){
                                                                            exit = 1;
                                                                        }
                                                                    }
                                                                }
                                                                if(!numberOfLecture.containsKey(lecturerToBeAssigned)){
                                                                    numberOfLecture.put(lecturerToBeAssigned, 0);
                                                                }
                                                                if(lecturerToBeAssigned == 0){
                                                                    lecturerToBeAssigned = timetable.getLecturersAsArray().length;
                                                                    numberOfLecture.replace(lecturerToBeAssigned, numberOfLecture.get(lecturerToBeAssigned)+1);
                                                                    checked = true;
                                                                }
                                                                
                                                                offspring.setGene(geneIndex, lecturerToBeAssigned);
                                                                //System.out.println("aaaahhhhh");
                                                            }
                                                            if(checked){
                                                                break;
                                                            }
                                                    
                                                        //System.out.println("bkbkbkb");
                                                        }
                                                        if(checked){
                                                            break;                                                            
                                                        }
                                                }
                                            }
                                        }
                                        //System.out.println("eeaabb");
                                        if(checked){
                                            //System.out.println("effff");
                                            continue;
                                        }
                                        
                                        if (atRoomOffset){
                                            //System.out.println("crossover checked1");
                                            Individual offspringTemp  = new Individual(timetable);
                                            for (Section section : timetable.getSectionsAsArray()) {
                                                // Loop through courses
                                                int chromInd = 0;
                                                for (int courseId : section.getCourseIds()) {
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        offspringTemp.setGene(chromInd, offspring.getGene(chromInd));
                                                        chromInd ++;
                                                        //System.out.println("wow"+offspring.getGene(chromInd-1));
                                                }
                                            }
                                            timetable.createslots(offspringTemp);
                                            //System.out.println("daniel: " + timetable.getNumslots());
                                            Slot[] slot = timetable.getslots();
                                            //System.out.println("ante " + slot.length + " , " + slot[useful].getSectionId());
                                            boolean returned = false;
                                            if(classroomPreference.containsKey(slot[useful].getSectionId())){
                                                //System.out.println("crossover checked222");
                                                int[] rooms =  classroomPreference.get(slot[useful].getSectionId());
                                                for(int room: rooms){
                                                    if(room == slot[useful].getRoomId()){
                                                        returned = true;
                                                        geneIndex -= 3;
                                                        break;
                                                    }
                                                }                                       
                                                //System.out.println("crossover checked");
                                            } 
                                            if(periodPreference.containsKey(slot[useful].getLecturerId()) && (!returned)){
                                                int[] periods = periodPreference.get(slot[useful].getLecturerId());
                                                //System.out.println("crossover checked3 " + periodPreference.get(1)[0]);
                                                for(int period: periods){
                                                    if(period == slot[useful].getPeriodId()){
                                                        geneIndex -= 3;
                                                        break;
                                                    }
                                                } 
                                            }
                                            returned = false;
                                        }
                                        
                                        // Use half of parent1's genes and half of parent2's genes
                                        if (0.5 > Math.random()) {
						offspring.setGene(geneIndex, parent1.getGene(geneIndex));
                                                //System.out.println("gi " + geneIndex + " , " + parent1.getGene(geneIndex));
					} else {
						offspring.setGene(geneIndex, parent2.getGene(geneIndex));
                                                //System.out.println("gene index: " + geneIndex + ", gene: " + offspring.getGene(geneIndex));
					}
				}
                        
                            // Add offspring to new population
                            newPopulation.setIndividual(populationIndex, offspring);
			}
                        else {
                            // Add individual to new population without applying crossover
                            newPopulation.setIndividual(populationIndex, parent1);
			}
                    }
                    return newPopulation;
		}
  
        }

