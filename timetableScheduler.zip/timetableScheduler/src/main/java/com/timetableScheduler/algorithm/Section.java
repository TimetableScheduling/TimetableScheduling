/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */

public class Section {
    private final int sectionId;
    private final int sectionSize;
    private final int courseIds[];
    private String sectionName;
    /**
     * Initialize Section
     * 
     * @param sectionId
     * @param sectionSize
     * @param courseIds
     */
    public Section(int sectionId, int sectionSize, int courseIds[]){
        this.sectionId = sectionId;
        this.sectionSize = sectionSize;
        this.courseIds = courseIds;
    }
    public Section(int sectionId, String sectionName, int sectionSize, int courseIds[]){
        this.sectionId = sectionId;
        this.sectionSize = sectionSize;
        this.courseIds = courseIds;
        this.sectionName = sectionName;
        
    }
    /**
     * Get sectionId
     * 
     * @return sectionId
     */
    public int getSectionId(){
        return this.sectionId;
    }
    
    /**
     * Get sectionSize
     * 
     * @return sectionSize
     */
    public int getSectionSize(){
        return this.sectionSize;
    }
        
    /**
     * Get array of section's courseIds
     * 
     * @return courseIds
     */
    public int[] getCourseIds(){
        return this.courseIds;
    }
    
    public String getSectionName(){
        return this.sectionName;
    }
}
