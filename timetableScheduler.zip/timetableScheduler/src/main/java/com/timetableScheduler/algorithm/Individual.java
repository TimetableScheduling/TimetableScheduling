/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import org.slf4j.LoggerFactory;

import static javafx.scene.input.KeyCode.I;

/**
 *
 * @author Daniel
 */

public class Individual {
	
	//The chromosome is an array of integers. 
	private int[] chromosome;
	private double fitness = -1;
//	static org.slf4j.Logger  logger = LoggerFactory.getLogger(Individual.class);

        //individual that considers the preference of lecturer and sections
        public Individual(Timetable timetable) {
		int numslots = timetable.getNumslots();
                
		// 1 gene for room, 1 for period, 1 for Lecturer
		int chromosomeLength = numslots * 3;
		
                //To Create random individual for the given chromosome length of the individual
		int newChromosome[] = new int[chromosomeLength];
		int chromosomeIndex = 0;
                HashMap<Integer, Integer> numberOfLecture = new HashMap<>();
		// Loop through sections
                
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePriority = new HashMap<>();
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
//                    logger.info("preferring "+preferring);
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnIndiv " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnIndiv " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePriority.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(preferring));
                            break;
                        default:
                            break;
                    }
                });
                
		for (Section section : timetable.getSectionsAsArray()) {
//                    logger.info("section "+section.getSectionName());
			// Loop through courses
			for (int courseId : section.getCourseIds()) {
                                Course course = timetable.getCourse(courseId);
//                                logger.info("course "+course.getCourseName());
                                int lecturerToBeAssigned = course.getRandomLecturerId();
                                //the lecturer would be added at the third position after period and room (+2+)
                                //System.out.println(""chromosomeIndex);
                                newChromosome[chromosomeIndex + 2] = lecturerToBeAssigned;
                                // Add random room
                                
				int roomId = timetable.getRandomRoom().getRoomId();
                                //System.out.println("rooomId"+roomId);
                                for(int i = 0; i<classroomPreference.size(); i++){
                                    if(classroomPreference.containsKey(section.getSectionId())){  
                                        //System.out.println("yes IT CONTAINS");
                                        
                                        int[] rooms = classroomPreference.get(section.getSectionId());
                                       
                                        //System.out.println("room length, room 0: " + rooms.length + ",  "+rooms[0]);                                        
                                        boolean check = false;
                                        for(int room: rooms){
                                            if(room == roomId){
                                                check = true;
                                                break;
                                            }
                                        }                                       
                                        while(check){
                                            roomId = timetable.getRandomRoom().getRoomId();
                                            for(int room: rooms){
                                                if(room != roomId){
//                                                    logger.info("check = false; at room"+room);
                                                    check = false;
                                                }
                                                else{
//                                                    System.out.println("chcking done here too: " + roomId + " , " + room);                                                
                                                    check = true;
                                                    break;
                                                }
                                            }
                                            
                                        }
                                        //System.out.println("finally, " + roomId);
                                    }
                                    
                                }
//                                System.out.println("hr"+roomId);
				newChromosome[chromosomeIndex] = roomId;
                                //System.out.println("chr ind: "+chromosomeIndex + " , roomId: " + roomId);
                                chromosomeIndex++;
				// Add random time
				int periodId = timetable.getRandomPeriod().getPeriodId();
                                for(int i = 0; i<periodPreference.size(); i++){
                                    if(periodPreference.containsKey(newChromosome[chromosomeIndex + 1])){
                                        //System.out.println("Yes It contains");
                                        int[] periods = periodPreference.get(newChromosome[chromosomeIndex + 1]);
                                        //System.out.println("point here " + periods.length + ",  "+periods[0]);
                                        boolean check = false;
                                        for(int period: periods){
                                            if(period == periodId){
                                                check = true;
                                            }
                                        }                                       
                                        while(check == true){
                                            periodId = timetable.getRandomPeriod().getPeriodId();
                                            for(int period: periods){
                                                if(period != periodId){
//                                                	logger.info("check = false; at period"+period);
                                                    check = false;
                                                }
                                                else{
//                                                    System.out.println("chcking done here too: " + periodId + " , " + period);                                                
                                                    check = true;
                                                    break;
                                                }
                                            }
                                            
                                        }
//                                        System.out.println("finally, " + periodId);
                                    }
                                    
                                }
				newChromosome[chromosomeIndex] = periodId;
								
				chromosomeIndex++;
                                chromosomeIndex++;
                        }
		}

		this.chromosome = newChromosome;
                //System.out.println("the chromosome becomes" +Arrays.toString(this.chromosome));
	}
	
        //this constructor is for lecturer maximum effort
        public Individual(Timetable timetable,int a ) {
		int numslots = timetable.getNumslots();
                
		// 1 gene for room, 1 for period, 1 for Lecturer
		int chromosomeLength = numslots * 3;
		
                //To Create random individual for the given chromosome length of the individual
		int newChromosome[] = new int[chromosomeLength];
		int chromosomeIndex = 0;
                HashMap<Integer, Integer> numberOfLecture = new HashMap<>();
		// Loop through sections
                
                HashMap<Integer,int[]> periodPreference = new HashMap<>();
                HashMap<Integer, int[]> classroomPreference = new HashMap<>();
                HashMap<Integer, int[]> coursePriority = new HashMap<>();
                timetable.getPreferences().keySet().forEach((keys) -> {
                    int preferring = timetable.getPreferences().get(keys).getPreferring();
                    switch (timetable.getPreferences().get(keys).getPreferenceType()) {
                        case 1:
                            //System.out.println(" jkfdld" + timetable.getPreferences().get(keys).getPeriodPreference(preferring).length);
                            periodPreference.put(preferring, timetable.getPreferences().get(keys).getPeriodPreference(preferring));
                            //System.out.println("periodPrefOnIndiv " + preferring + " " + periodPreference.get(preferring)[4]);
                            break;
                        case 2:
                            classroomPreference.put(preferring, timetable.getPreferences().get(keys).getClassroomPreference(preferring));
                            //System.out.println("ClassroomPrefOnIndiv " + preferring + " " + classroomPreference.get(preferring)[0]);
                            break;
                        case 3:
                            coursePriority.put(preferring, timetable.getPreferences().get(keys).getCoursePreference(preferring));
                            break;
                        default:
                            break;
                    }
                });
                
		for (Section section : timetable.getSectionsAsArray()) {
                    
			// Loop through courses
			for (int courseId : section.getCourseIds()) {
                                Course course = timetable.getCourse(courseId);
                                int lecturerToBeAssigned = course.getRandomLecturerId();
                         
                                //to check whether the lecturer attains the maximum limit to give a service of                               
                                if(!numberOfLecture.containsKey(lecturerToBeAssigned)){
                                    numberOfLecture.put(lecturerToBeAssigned, 0);
                                }
                                int maxEff = timetable.getLecturer(lecturerToBeAssigned).getMaximumEffort();
                                if(numberOfLecture.get(lecturerToBeAssigned) < maxEff) {
                                    //System.out.println("in the if condition, courseId" + courseId);
                                    numberOfLecture.replace(lecturerToBeAssigned, numberOfLecture.get(lecturerToBeAssigned)+1);
                                        //System.out.println(maxEff +" Aygermim, andandie " + lecturerToBeAssigned);                                            
                                }
                                else{
                                    //System.out.println("int the else condition, courseId " + courseId);
                                        int temp =0;
                                        int exit = 0;
                                        while(exit==0){
                                            //System.out.println("in the while loop " + temp);
                                            int[] lectList = course.LecturerIds;
                                            for(int index =0;index<lectList.length;index++){
                                                if(!numberOfLecture.containsKey(lectList[index])){
                                                    numberOfLecture.put(lectList[index], 0);
                                                }
                                                maxEff = timetable.getLecturer(lectList[index]).getMaximumEffort();
                                                if(numberOfLecture.get(lectList[index]) < maxEff){
                                                    numberOfLecture.replace(lectList[index], numberOfLecture.get(lectList[index])+1);
                                                    temp = lectList[index];
                                                    exit = 1;
                                                    break;
                                                }
                                                if(index == lectList.length-1){
                                                    exit = 1;
                                                }
                                            }
                                        }
                                        if(temp == 0){
                                            temp = timetable.getLecturersAsArray().length;
                                        }
                                        lecturerToBeAssigned = temp;
                                        if(!numberOfLecture.containsKey(lecturerToBeAssigned)){
                                            numberOfLecture.put(lecturerToBeAssigned, 0);
                                        }
                                        
                                }
                                
                                //the lecturer would be added at the third position after period and room (+2+)
                                //System.out.println(""chromosomeIndex);
                                newChromosome[chromosomeIndex + 2] = lecturerToBeAssigned;
                                // Add random room
                                
				int roomId = timetable.getRandomRoom().getRoomId();
                                //System.out.println("rooomId"+roomId);
                                for(int i = 0; i<classroomPreference.size(); i++){
                                    if(classroomPreference.containsKey(section.getSectionId())){  
                                        //System.out.println("yes IT CONTAINS");
                                        
                                        int[] rooms = classroomPreference.get(section.getSectionId());
                                       
                                        //System.out.println("room length, room 0: " + rooms.length + ",  "+rooms[0]);                                        
                                        boolean check = false;
                                        for(int room: rooms){
                                            if(room == roomId){
                                                check = true;
                                                break;
                                            }
                                        }                                       
                                        while(check){
                                            roomId = timetable.getRandomRoom().getRoomId();
                                            for(int room: rooms){
                                                if(room != roomId){
                                                    //System.out.println("chcking done here: " + roomId + " , " + room);
                                                    check = false;
                                                }
                                                else{
                                                    //System.out.println("chcking done here too: " + roomId + " , " + room);                                                
                                                    check = true;
                                                    break;
                                                }
                                            }
                                            
                                        }
                                        //System.out.println("finally, " + roomId);
                                    }
                                    
                                }
                                //System.out.println("hr"+roomId);
				newChromosome[chromosomeIndex] = roomId;
                                //System.out.println("chr ind: "+chromosomeIndex + " , roomId: " + roomId);
                                chromosomeIndex++;
				// Add random time
				int periodId = timetable.getRandomPeriod().getPeriodId();
                                for(int i = 0; i<periodPreference.size(); i++){
                                    if(periodPreference.containsKey(newChromosome[chromosomeIndex + 1])){
                                        //System.out.println("Yes It contains");
                                        int[] periods = periodPreference.get(newChromosome[chromosomeIndex + 1]);
                                        //System.out.println("point here " + periods.length + ",  "+periods[0]);
                                        boolean check = false;
                                        for(int period: periods){
                                            if(period == periodId){
                                                check = true;
                                            }
                                        }                                       
                                        while(check == true){
                                            periodId = timetable.getRandomPeriod().getPeriodId();
                                            for(int period: periods){
                                                if(period != periodId){
                                                    //System.out.println("chcking done here: " + periodId + " , " + period);
                                                    check = false;
                                                }
                                                else{
                                                    //System.out.println("chcking done here too: " + periodId + " , " + period);                                                
                                                    check = true;
                                                    break;
                                                }
                                            }
                                            
                                        }
                                        //System.out.println("finally, " + periodId);
                                    }
                                    
                                }
				newChromosome[chromosomeIndex] = periodId;
								
				chromosomeIndex++;
                                chromosomeIndex++;
                        }
		}

		this.chromosome = newChromosome;
                //System.out.println("the chromosome becomes" +Arrays.toString(this.chromosome));
	}

       	// Initialize random individual by the given chromosome length	 
        //create an individual with its size and sample gene
	public Individual(int chromosomeLength) {
		// Create random individual
		int[] individual;
		individual = new int[chromosomeLength];
		
		for (int gene = 0; gene < chromosomeLength; gene++) {
			individual[gene] = 40;
		}
		
		this.chromosome = individual;
	}
    
	//Initializes individual with specific chromosome
	 
	public Individual(int[] chromosome) {
		// Create individual chromosome
		this.chromosome = chromosome;
	}

	// To get the individual's chromosome
	 
	public int[] getChromosome() {
		return this.chromosome;
	}

	//To get the individual's chromosome length
	 
	public int getChromosomeLength() {
		return this.chromosome.length;
	}

	// To set gene at the given offset
	public void setGene(int offset, int gene) {
		this.chromosome[offset] = gene;
	}

	// To get gene at the given offset
	public int getGene(int offset) {
		return this.chromosome[offset];
	}

	//To store the individual's fitness
	public void setFitness(double fitness) {
		this.fitness = fitness;
	}

	//To get the individual's fitness
	public double getFitness() {
		return this.fitness;
	}
	
	public String toString() {
		String output = "";
		for (int gene = 0; gene < this.chromosome.length; gene++) {
                    if(gene == this.chromosome.length-1){
                        output += this.chromosome[gene];
                    }
                    else{
                        output += this.chromosome[gene] + ",";
                    }
		}
		return output;
	}

	//Search for a specific gene in this individual.
	public boolean containsGene(int gene) {
		for (int i = 0; i < this.chromosome.length; i++) {
			if (this.chromosome[i] == gene) {
				return true;
			}
		}
		return false;
	}


	
}
