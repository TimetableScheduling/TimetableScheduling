/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */


public class Period {
    private final int periodId;
    private final String period;
    
    /**
     * Initalize new Period
     * 
     * @param periodId The Id for this period
     * @param period The period being initalized
     */
    public Period(int periodId, String period){
        this.periodId = periodId;
        this.period = period;
    }
    
    /**
     * Returns the periodId
     * 
     * @return periodId
     */
    public int getPeriodId(){
        return this.periodId;
    }
    
    /**
     * Returns the period
     * 
     * @return period
     */
    public String getPeriod(){
        return this.period;
    }
}

