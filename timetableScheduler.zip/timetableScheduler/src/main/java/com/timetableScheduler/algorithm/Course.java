/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.timetableScheduler.algorithm;

/**
 *
 * @author Daniel
 */

/**
 * Simple course course abstraction, which defines the Lecturers teaching the course.
 */
public class Course {
    private final int courseId;
    private final String courseCode;
    private final String course;
    public final int LecturerIds[];
    
    /**
     * Initialize new Course
     * 
     * @param courseId
     * @param courseCode
     * @param course
     * @param LecturerIds
     */
    public Course(int courseId, String courseCode, String course, int LecturerIds[]){
        this.courseId = courseId;
        this.courseCode = courseCode;
        this.course = course;
        this.LecturerIds = LecturerIds;
    }
    
    /**
     * Get courseId
     * 
     * @return courseId
     */
    public int getCourseId(){
        return this.courseId;
    }
    
    /**
     * Get course code
     * 
     * @return courseCode
     */
    public String getCourseCode(){
        return this.courseCode;
    }
    
    /**
     * Get course name
     * 
     * @return courseName
     */
    public String getCourseName(){
        return this.course;
    }
    
    public int[] getLecturers(){
        
        return this.LecturerIds;
    }
    
    /**
     * Get random Lecturer Id
     * 
     * @return LecturerId
     */
    public int getRandomLecturerId(){
        //System.out.println("course: "+this.getCourseName() + " \nno Lecturers :"+LecturerIds.length);
        int LecturerId= LecturerIds[(int) (LecturerIds.length * Math.random())];
        //System.out.println("The random lecturer id here is: "+ LecturerId);

        return LecturerId;
    }
}

