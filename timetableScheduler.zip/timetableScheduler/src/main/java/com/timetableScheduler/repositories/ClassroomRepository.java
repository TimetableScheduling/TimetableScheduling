package com.timetableScheduler.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;

public interface ClassroomRepository extends CrudRepository<Classroom, Integer> {
	Classroom findByWhoTeachHereContainsAndBusyAtContains(Lecturer lecturer,Period period);
	ArrayList<Classroom> findBySchool(School school);
	ArrayList<Classroom> findBySchoolAndContainingSlotsNotNull(School school);
	List<Classroom> findByPreferringSectionsContains(Section section);
}
