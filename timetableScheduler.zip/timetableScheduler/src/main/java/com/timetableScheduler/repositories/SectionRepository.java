package com.timetableScheduler.repositories;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;

public interface SectionRepository extends CrudRepository<Section,Integer>{
	List<Section> findByBatch(String batch);
	Section findByHasClassesAtContainsAndAssignedLecturersContains(Period period,Lecturer lecturer);
	ArrayList<Section> findBySchool(School school);
	ArrayList<Section> findBySchoolAndContainingSlotsNotNull(School school);
}
