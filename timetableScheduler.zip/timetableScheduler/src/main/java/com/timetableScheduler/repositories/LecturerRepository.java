package com.timetableScheduler.repositories;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;

public interface LecturerRepository extends CrudRepository<Lecturer,Integer>{
	Lecturer findByUsername(String username);
	Lecturer findByLecturerId(String lecturerId);
	ArrayList<Lecturer> findBySchoolAndApproved(School school,boolean approved);
	ArrayList<Lecturer> findBySchool(School school);
	ArrayList<Lecturer> findBySchoolAndContainingSlotNotNull(School school);
	List<Lecturer> findByCouldTeacheContains(Course course);
}
