package com.timetableScheduler.repositories;

import java.util.ArrayList;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;
import com.timetableScheduler.models.Slot;

public interface SlotRepository extends CrudRepository<Slot,Integer>{
	Slot findByPeriodAndSection(Period period,Section section);
	Slot findByPeriodAndClassroom(Period period,Classroom classroom);
	Slot findByPeriodAndLecturer(Period period,Lecturer lecturer);
	Iterable<Slot> findBySection(Section section);
	Iterable<Slot> findByLecturer(Lecturer lecturer);
	Iterable<Slot> findByClassroom(Classroom classroom);
	ArrayList<Slot> findBySchool(School school);
}
