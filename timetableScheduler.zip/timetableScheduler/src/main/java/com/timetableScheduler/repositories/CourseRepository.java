package com.timetableScheduler.repositories;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.Course;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.School;
import com.timetableScheduler.models.Section;

public interface CourseRepository extends CrudRepository<Course,Integer>{
	Course findByTeachingTeachersContainsAndTimeCourseGivenContains(Lecturer lecturer,Period period);
	ArrayList<Course> findBySchool(School school);
	List<Course> findByTakerSectionIn(Section section);
	List<Course> findByAbleTeachersContains(Lecturer lecturer);
}
