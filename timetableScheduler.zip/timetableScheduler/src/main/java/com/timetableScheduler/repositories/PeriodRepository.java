package com.timetableScheduler.repositories;

import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.constants.Days;
import com.timetableScheduler.constants.Sessions;
import com.timetableScheduler.models.Classroom;
import com.timetableScheduler.models.Lecturer;
import com.timetableScheduler.models.Period;
import com.timetableScheduler.models.Section;

public interface PeriodRepository extends CrudRepository<Period,Integer>{
	List<Period> findByLecturerPreferenceContains(Lecturer lecturer);
	List<Period> findByLecturerAssignmentContains(Lecturer lecturer);
	List<Period> findByAssignedSectionsContains(Section section);
	List<Period> findByAssignedClassroomsContains(Classroom classroom);
}
