package com.timetableScheduler.repositories;

import org.springframework.data.repository.CrudRepository;

import com.timetableScheduler.models.School;
public interface SchoolRepository extends CrudRepository<School,Integer>{
	School findByUsername(String username);
	School findByUsernameAndPassword(String username,String password);
}
